const mixedQuestions = [
    {
        question: 'Create a responsive navigation bar with hamburger menu for mobile',
        initialCode: `<nav class="navbar">
  <div class="brand">Logo</div>
  <button class="hamburger">☰</button>
  <ul class="nav-menu">
    <li><a href="#home">Home</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#services">Services</a></li>
    <li><a href="#contact">Contact</a></li>
  </ul>
</nav>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<nav class="navbar">
  <div class="brand">Logo</div>
  <button class="hamburger" onclick="toggleMenu()">☰</button>
  <ul class="nav-menu">
    <li><a href="#home">Home</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#services">Services</a></li>
    <li><a href="#contact">Contact</a></li>
  </ul>
</nav>

<style>
  .navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    background: #333;
    color: white;
  }
  
  .nav-menu {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
    gap: 1rem;
  }
  
  .nav-menu a {
    color: white;
    text-decoration: none;
    transition: color 0.3s;
  }
  
  .nav-menu a:hover {
    color: #ddd;
  }
  
  .hamburger {
    display: none;
    background: none;
    border: none;
    color: white;
    font-size: 1.5rem;
    cursor: pointer;
  }
  
  @media (max-width: 768px) {
    .hamburger {
      display: block;
    }
    
    .nav-menu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: #333;
      flex-direction: column;
      padding: 1rem;
    }
    
    .nav-menu.active {
      display: flex;
    }
  }
</style>

<script>
  function toggleMenu() {
    const menu = document.querySelector('.nav-menu');
    menu.classList.toggle('active');
  }
</script>`,
        hint: 'Use CSS media queries for responsiveness and JavaScript for the hamburger menu toggle'
    },
    {
        question: 'Build an image slider with next/previous buttons',
        initialCode: `<div class="slider-container">
  <div class="slider">
    <img src="https://picsum.photos/600/300?random=1" alt="Slide 1">
    <img src="https://picsum.photos/600/300?random=2" alt="Slide 2">
    <img src="https://picsum.photos/600/300?random=3" alt="Slide 3">
  </div>
  <button class="prev">Previous</button>
  <button class="next">Next</button>
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<div class="slider-container">
  <div class="slider">
    <img src="https://picsum.photos/600/300?random=1" alt="Slide 1">
    <img src="https://picsum.photos/600/300?random=2" alt="Slide 2">
    <img src="https://picsum.photos/600/300?random=3" alt="Slide 3">
  </div>
  <button class="prev">❮</button>
  <button class="next">❯</button>
  <div class="dots"></div>
</div>

<style>
  .slider-container {
    position: relative;
    max-width: 600px;
    margin: 0 auto;
    overflow: hidden;
  }
  
  .slider {
    display: flex;
    transition: transform 0.5s ease-in-out;
  }
  
  .slider img {
    width: 100%;
    flex-shrink: 0;
  }
  
  button {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(0,0,0,0.5);
    color: white;
    border: none;
    padding: 10px 15px;
    cursor: pointer;
  }
  
  .prev { left: 10px; }
  .next { right: 10px; }
  
  .dots {
    position: absolute;
    bottom: 10px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 10px;
  }
</style>

<script>
  const slider = document.querySelector('.slider');
  let currentSlide = 0;
  
  function nextSlide() {
    currentSlide = (currentSlide + 1) % 3;
    updateSlider();
  }
  
  function prevSlide() {
    currentSlide = (currentSlide - 1 + 3) % 3;
    updateSlider();
  }
  
  function updateSlider() {
    slider.style.transform = \`translateX(-\${currentSlide * 100}%)\`;
  }
  
  document.querySelector('.next').addEventListener('click', nextSlide);
  document.querySelector('.prev').addEventListener('click', prevSlide);
</script>`,
        hint: 'Use CSS transitions for smooth animations and JavaScript for slide control'
    },
    {
        question: 'Create a dynamic todo list with local storage',
        initialCode: `<div class="todo-app">
  <input type="text" id="todoInput" placeholder="Add new task...">
  <button id="addTodo">Add</button>
  <ul id="todoList"></ul>
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<div class="todo-app">
  <header>
    <h1>Todo List</h1>
    <div class="input-group">
      <input type="text" id="todoInput" placeholder="Add new task...">
      <button id="addTodo">Add</button>
    </div>
  </header>
  <ul id="todoList"></ul>
  <footer>
    <span id="taskCount">0 tasks remaining</span>
    <button id="clearCompleted">Clear Completed</button>
  </footer>
</div>

<style>
  .todo-app {
    max-width: 400px;
    margin: 20px auto;
    padding: 20px;
    background: #f5f5f5;
    border-radius: 8px;
  }
  
  input {
    padding: 8px;
    margin-right: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
  }
  
  button {
    padding: 8px 16px;
    background: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  ul {
    list-style: none;
    padding: 0;
  }
  
  li {
    display: flex;
    align-items: center;
    padding: 8px;
    background: white;
    margin: 8px 0;
    border-radius: 4px;
  }
  
  li.completed {
    opacity: 0.7;
    text-decoration: line-through;
  }
</style>

<script>
  const todoInput = document.getElementById('todoInput');
  const todoList = document.getElementById('todoList');
  let todos = JSON.parse(localStorage.getItem('todos')) || [];
  
  function addTodo() {
    const text = todoInput.value.trim();
    if(text) {
      todos.push({ id: Date.now(), text, completed: false });
      saveTodos();
      renderTodos();
      todoInput.value = '';
    }
  }
  
  function renderTodos() {
    todoList.innerHTML = '';
    todos.forEach(todo => {
      const li = document.createElement('li');
      li.innerHTML = \`
        <input type="checkbox" \${todo.completed ? 'checked' : ''}>
        <span>\${todo.text}</span>
        <button>Delete</button>
      \`;
      todoList.appendChild(li);
    });
  }
  
  function saveTodos() {
    localStorage.setItem('todos', JSON.stringify(todos));
  }
  
  document.getElementById('addTodo').addEventListener('click', addTodo);
  renderTodos();
</script>`,
        hint: 'Use localStorage for data persistence and event listeners for interactivity'
    },
    {
        question: 'Build a modal popup with overlay',
        initialCode: `<button id="openModal">Open Modal</button>
<div id="modal" class="modal">
  <!-- Add modal content here -->
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<button id="openModal">Open Modal</button>
<div id="modal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h2>Modal Title</h2>
    <p>This is a modal popup with an overlay background.</p>
    <button class="modal-btn">OK</button>
  </div>
</div>

<style>
  .modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
  }
  
  .modal-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 20px;
    border-radius: 5px;
    min-width: 300px;
  }
  
  .close {
    float: right;
    cursor: pointer;
    font-size: 24px;
  }
  
  .modal.active {
    display: block;
  }
</style>

<script>
  const modal = document.getElementById('modal');
  const openBtn = document.getElementById('openModal');
  const closeBtn = document.querySelector('.close');
  
  openBtn.onclick = () => modal.classList.add('active');
  closeBtn.onclick = () => modal.classList.remove('active');
  
  window.onclick = (e) => {
    if (e.target === modal) {
      modal.classList.remove('active');
    }
  }
</script>`,
        hint: 'Use fixed positioning for the overlay and absolute positioning for the modal content'
    },
    {
        question: 'Create a countdown timer',
        initialCode: `<div class="timer">
  <input type="number" id="minutes" min="0" max="60">
  <button id="startTimer">Start</button>
  <div id="display"></div>
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<div class="timer">
  <div class="timer-input">
    <input type="number" id="minutes" min="0" max="60" placeholder="Minutes">
    <button id="startTimer">Start</button>
    <button id="resetTimer">Reset</button>
  </div>
  <div id="display" class="display">00:00</div>
</div>

<style>
  .timer {
    text-align: center;
    padding: 20px;
  }
  
  .display {
    font-size: 48px;
    font-family: monospace;
    margin: 20px 0;
  }
  
  input {
    padding: 8px;
    width: 80px;
    margin-right: 10px;
  }
  
  button {
    padding: 8px 16px;
    margin: 0 5px;
  }
</style>

<script>
  let timeLeft;
  let timerId = null;
  
  const display = document.getElementById('display');
  const startBtn = document.getElementById('startTimer');
  const resetBtn = document.getElementById('resetTimer');
  
  function startTimer() {
    if (timerId) return;
    
    const minutes = parseInt(document.getElementById('minutes').value);
    timeLeft = minutes * 60;
    
    timerId = setInterval(() => {
      if (timeLeft <= 0) {
        clearInterval(timerId);
        timerId = null;
        return;
      }
      
      timeLeft--;
      updateDisplay();
    }, 1000);
  }
  
  function updateDisplay() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    display.textContent = \`\${minutes.toString().padStart(2, '0')}:\${seconds.toString().padStart(2, '0')}\`;
  }
  
  function resetTimer() {
    clearInterval(timerId);
    timerId = null;
    timeLeft = 0;
    display.textContent = '00:00';
  }
  
  startBtn.addEventListener('click', startTimer);
  resetBtn.addEventListener('click', resetTimer);
</script>`,
        hint: 'Use setInterval for the countdown and format the time display with padStart'
    },
    {
        question: 'Build a color picker with RGB sliders',
        initialCode: `<div class="color-picker">
  <!-- Add color picker elements here -->
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<div class="color-picker">
  <div class="color-preview"></div>
  <div class="sliders">
    <div class="slider-group">
      <label>R</label>
      <input type="range" min="0" max="255" value="0" class="slider" id="red">
      <span class="value">0</span>
    </div>
    <div class="slider-group">
      <label>G</label>
      <input type="range" min="0" max="255" value="0" class="slider" id="green">
      <span class="value">0</span>
    </div>
    <div class="slider-group">
      <label>B</label>
      <input type="range" min="0" max="255" value="0" class="slider" id="blue">
      <span class="value">0</span>
    </div>
  </div>
  <div class="color-code">rgb(0, 0, 0)</div>
</div>

<style>
  .color-picker {
    max-width: 300px;
    padding: 20px;
    background: #f5f5f5;
    border-radius: 8px;
  }
  
  .color-preview {
    width: 100%;
    height: 100px;
    border: 2px solid #ddd;
    margin-bottom: 20px;
  }
  
  .slider-group {
    display: flex;
    align-items: center;
    margin: 10px 0;
  }
  
  .slider-group label {
    width: 20px;
  }
  
  .slider {
    flex: 1;
    margin: 0 10px;
  }
  
  .color-code {
    text-align: center;
    margin-top: 20px;
    font-family: monospace;
  }
</style>

<script>
  const preview = document.querySelector('.color-preview');
  const colorCode = document.querySelector('.color-code');
  const sliders = document.querySelectorAll('.slider');
  
  function updateColor() {
    const red = document.getElementById('red').value;
    const green = document.getElementById('green').value;
    const blue = document.getElementById('blue').value;
    
    const color = \`rgb(\${red}, \${green}, \${blue})\`;
    preview.style.backgroundColor = color;
    colorCode.textContent = color;
    
    sliders.forEach(slider => {
      slider.nextElementSibling.textContent = slider.value;
    });
  }
  
  sliders.forEach(slider => {
    slider.addEventListener('input', updateColor);
  });
  
  updateColor();
</script>`,
        hint: 'Use range inputs for the RGB values and update the preview in real-time'
    },
    {
        question: 'Create a drag and drop file uploader',
        initialCode: `<div class="drop-zone">
  <!-- Add drop zone content here -->
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<div class="drop-zone">
  <div class="drop-zone-prompt">
    <i class="fas fa-cloud-upload-alt"></i>
    <p>Drag & Drop files here<br>or<br>Click to browse</p>
  </div>
  <input type="file" class="file-input" multiple hidden>
  <div class="file-list"></div>
</div>

<style>
  .drop-zone {
    width: 100%;
    max-width: 400px;
    height: 200px;
    padding: 25px;
    border: 2px dashed #ccc;
    border-radius: 10px;
    text-align: center;
    transition: border 0.3s ease;
  }
  
  .drop-zone.dragover {
    border-color: #4CAF50;
    background: rgba(76, 175, 80, 0.1);
  }
  
  .drop-zone-prompt {
    cursor: pointer;
  }
  
  .drop-zone-prompt i {
    font-size: 48px;
    color: #666;
  }
  
  .file-list {
    margin-top: 20px;
    text-align: left;
  }
  
  .file-item {
    display: flex;
    align-items: center;
    padding: 8px;
    background: #f5f5f5;
    margin: 5px 0;
    border-radius: 4px;
  }
</style>

<script>
  const dropZone = document.querySelector('.drop-zone');
  const fileInput = document.querySelector('.file-input');
  const fileList = document.querySelector('.file-list');
  
  dropZone.addEventListener('click', () => fileInput.click());
  
  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });
  
  ['dragleave', 'dragend'].forEach(type => {
    dropZone.addEventListener(type, () => {
      dropZone.classList.remove('dragover');
    });
  });
  
  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    
    const files = [...e.dataTransfer.files];
    handleFiles(files);
  });
  
  fileInput.addEventListener('change', () => {
    const files = [...fileInput.files];
    handleFiles(files);
  });
  
  function handleFiles(files) {
    files.forEach(file => {
      const fileItem = document.createElement('div');
      fileItem.className = 'file-item';
      fileItem.innerHTML = \`
        <span>\${file.name}</span>
        <span>(\${(file.size / 1024).toFixed(1)} KB)</span>
      \`;
      fileList.appendChild(fileItem);
    });
  }
</script>`,
        hint: 'Handle both drag & drop and click events, and prevent default behaviors'
    },
    {
        question: 'Build a password strength meter',
        initialCode: `<div class="password-input">
  <input type="password" id="password">
  <div class="strength-meter"></div>
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<div class="password-input">
  <input type="password" id="password" placeholder="Enter password">
  <div class="strength-meter">
    <div class="meter-bar"></div>
  </div>
  <div class="strength-text">Password strength: <span>None</span></div>
  <ul class="requirements">
    <li data-requirement="length">At least 8 characters</li>
    <li data-requirement="uppercase">Contains uppercase letter</li>
    <li data-requirement="lowercase">Contains lowercase letter</li>
    <li data-requirement="number">Contains number</li>
    <li data-requirement="special">Contains special character</li>
  </ul>
</div>

<style>
  .password-input {
    max-width: 300px;
    padding: 20px;
  }
  
  input {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
  }
  
  .strength-meter {
    height: 4px;
    background: #ddd;
    margin-bottom: 10px;
  }
  
  .meter-bar {
    height: 100%;
    width: 0;
    transition: width 0.3s, background 0.3s;
  }
  
  .requirements {
    margin-top: 10px;
    padding-left: 20px;
  }
  
  .requirements li {
    color: #666;
  }
  
  .requirements li.valid {
    color: #4CAF50;
  }
</style>

<script>
  const password = document.getElementById('password');
  const meterBar = document.querySelector('.meter-bar');
  const strengthText = document.querySelector('.strength-text span');
  const requirements = document.querySelectorAll('.requirements li');
  
  const strengthLevels = {
    0: { color: '#ddd', text: 'None' },
    1: { color: '#ff4444', text: 'Weak' },
    2: { color: '#ffbb33', text: 'Medium' },
    3: { color: '#00C851', text: 'Strong' }
  };
  
  function checkStrength(password) {
    let strength = 0;
    const checks = {
      length: password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      special: /[^A-Za-z0-9]/.test(password)
    };
    
    Object.entries(checks).forEach(([requirement, valid]) => {
      const requirementEl = document.querySelector(\`[data-requirement="\${requirement}"]\`);
      if (valid) {
        requirementEl.classList.add('valid');
        strength++;
      } else {
        requirementEl.classList.remove('valid');
      }
    });
    
    return Math.min(3, Math.floor(strength / 2));
  }
  
  password.addEventListener('input', () => {
    const strength = checkStrength(password.value);
    const strengthInfo = strengthLevels[strength];
    
    meterBar.style.width = \`\${(strength / 3) * 100}%\`;
    meterBar.style.background = strengthInfo.color;
    strengthText.textContent = strengthInfo.text;
  });
</script>`,
        hint: 'Check for multiple criteria and update the meter in real-time'
    },
    {
        question: 'Create an infinite scroll image gallery',
        initialCode: `<div class="gallery">
  <!-- Add gallery content here -->
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<div class="gallery">
  <div class="gallery-container"></div>
  <div class="loading">Loading...</div>
</div>

<style>
  .gallery {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
  }
  
  .gallery-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 20px;
  }
  
  .gallery-item {
    position: relative;
    padding-bottom: 100%;
    overflow: hidden;
    border-radius: 8px;
  }
  
  .gallery-item img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
  }
  
  .gallery-item:hover img {
    transform: scale(1.1);
  }
  
  .loading {
    text-align: center;
    padding: 20px;
    display: none;
  }
  
  .loading.active {
    display: block;
  }
</style>

<script>
  const gallery = document.querySelector('.gallery-container');
  const loading = document.querySelector('.loading');
  let page = 1;
  let isLoading = false;
  
  async function loadImages() {
    if (isLoading) return;
    
    isLoading = true;
    loading.classList.add('active');
    
    try {
      const response = await fetch(\`https://picsum.photos/v2/list?page=\${page}&limit=10\`);
      const images = await response.json();
      
      images.forEach(image => {
        const item = document.createElement('div');
        item.className = 'gallery-item';
        item.innerHTML = \`<img src="\${image.download_url}" alt="\${image.author}">\`;
        gallery.appendChild(item);
      });
      
      page++;
    } catch (error) {
      console.error('Error loading images:', error);
    } finally {
      isLoading = false;
      loading.classList.remove('active');
    }
  }
  
  function handleScroll() {
    const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
    
    if (scrollTop + clientHeight >= scrollHeight - 100) {
      loadImages();
    }
  }
  
  window.addEventListener('scroll', handleScroll);
  loadImages();
</script>`,
        hint: 'Use Intersection Observer or scroll events to detect when to load more images'
    },
    {
        question: 'Build a real-time search filter',
        initialCode: `<div class="search-container">
  <input type="text" id="search">
  <ul id="list">
    <!-- Add list items here -->
  </ul>
</div>

<style>
  /* Add your styles here */
</style>

<script>
  // Add your JavaScript here
</script>`,
        solution: `<div class="search-container">
  <div class="search-input">
    <i class="fas fa-search"></i>
    <input type="text" id="search" placeholder="Search items...">
    <span class="result-count"></span>
  </div>
  <ul id="list"></ul>
</div>

<style>
  .search-container {
    max-width: 500px;
    margin: 20px auto;
    padding: 20px;
  }
  
  .search-input {
    position: relative;
    margin-bottom: 20px;
  }
  
  .search-input i {
    position: absolute;
    left: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #666;
  }
  
  input {
    width: 100%;
    padding: 10px 10px 10px 35px;
    border: 1px solid #ddd;
    border-radius: 4px;
  }
  
  .result-count {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    color: #666;
    font-size: 14px;
  }
  
  #list {
    list-style: none;
    padding: 0;
  }
  
  .list-item {
    padding: 10px;
    border-bottom: 1px solid #eee;
    transition: background 0.3s;
  }
  
  .list-item:hover {
    background: #f5f5f5;
  }
  
  .highlight {
    background: yellow;
    padding: 0 2px;
  }
  
  .no-results {
    text-align: center;
    color: #666;
    padding: 20px;
  }
</style>

<script>
  const searchInput = document.getElementById('search');
  const list = document.getElementById('list');
  const resultCount = document.querySelector('.result-count');
  
  // Sample data - replace with your own
  const items = [
    'JavaScript',
    'Python',
    'Java',
    'C++',
    'Ruby',
    'PHP',
    'Swift',
    'TypeScript',
    'Go',
    'Rust'
  ];
  
  function renderList(items) {
    list.innerHTML = items.length ? 
      items.map(item => \`<li class="list-item">\${item}</li>\`).join('') :
      '<li class="no-results">No matching items found</li>';
      
    resultCount.textContent = items.length ? \`\${items.length} items\` : '';
  }
  
  function highlightMatch(text, search) {
    if (!search) return text;
    const regex = new RegExp(\`(\${search})\`, 'gi');
    return text.replace(regex, '<span class="highlight">$1</span>');
  }
  
  function filterItems(search) {
    const searchTerm = search.toLowerCase();
    return items.filter(item => 
      item.toLowerCase().includes(searchTerm)
    ).map(item => highlightMatch(item, search));
  }
  
  searchInput.addEventListener('input', (e) => {
    const filteredItems = filterItems(e.target.value);
    renderList(filteredItems);
  });
  
  // Initial render
  renderList(items);
</script>`,
    solution: `<div class="search-box">
  <input type="text" id="search" placeholder="Search items...">
  <div class="result-count"></div>
  <ul id="list"></ul>
</div>

<style>
  .search-box {
    max-width: 400px;
    margin: 20px auto;
    padding: 20px;
  }
  
  input {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
  }
  
  .result-count {
    font-size: 0.9em;
    color: #666;
    margin-bottom: 10px;
  }
  
  #list {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  
  .list-item {
    padding: 8px;
    border-bottom: 1px solid #eee;
  }
  
  .highlight {
    background: yellow;
  }
  
  .no-results {
    color: #666;
    font-style: italic;
  }
</style>

<script>
  const searchInput = document.getElementById('search');
  const list = document.getElementById('list');
  const resultCount = document.querySelector('.result-count');
  
  // Sample data - replace with your own
  const items = [
    'JavaScript',
    'Python', 
    'Java',
    'C++',
    'Ruby',
    'PHP',
    'Swift',
    'TypeScript',
    'Go',
    'Rust'
  ];
  
  function renderList(items) {
    list.innerHTML = items.length ? 
      items.map(item => \`<li class="list-item">\${item}</li>\`).join('') :
      '<li class="no-results">No matching items found</li>';
      
    resultCount.textContent = items.length ? \`\${items.length} items\` : '';
  }
  
  function highlightMatch(text, search) {
    if (!search) return text;
    const regex = new RegExp(\`(\${search})\`, 'gi');
    return text.replace(regex, '<span class="highlight">$1</span>');
  }
  
  function filterItems(search) {
    const searchTerm = search.toLowerCase();
    return items.filter(item => 
      item.toLowerCase().includes(searchTerm)
    ).map(item => highlightMatch(item, search));
  }
  
  searchInput.addEventListener('input', (e) => {
    const filteredItems = filterItems(e.target.value);
    renderList(filteredItems);
  });
  
  // Initial render
  renderList(items);
</script>`
}];

class CompilerQuiz {
    constructor() {
        this.editor = null;
        this.currentQuestionIndex = 0;
        this.initializeEditor();
        this.setupEventListeners();
        this.loadQuestion(0);
    }

    initializeEditor() {
        const editorElement = document.getElementById('codeEditor');
        if (!editorElement) {
            console.error('Editor element not found');
            return;
        }

        this.editor = CodeMirror(editorElement, {
            mode: 'xml',
            theme: 'default',
            lineNumbers: true,
            autoCloseTags: true,
            autoCloseBrackets: true,
            lineWrapping: true,
            value: '',
            extraKeys: {"Ctrl-Space": "autocomplete"},
            matchBrackets: true,
            indentUnit: 2,
            tabSize: 2,
            styleActiveLine: true
        });
    }

    setupEventListeners() {
        document.getElementById('runBtn')?.addEventListener('click', () => this.runCode());
        document.getElementById('askAIBtn')?.addEventListener('click', () => this.askAI());
        document.getElementById('solutionBtn')?.addEventListener('click', () => this.toggleSolution());
        document.getElementById('reviewBtn')?.addEventListener('click', () => this.reviewCode());
        document.getElementById('prevBtn')?.addEventListener('click', () => this.navigate(-1));
        document.getElementById('nextBtn')?.addEventListener('click', () => this.navigate(1));
    }

    navigate(direction) {
        const newIndex = this.currentQuestionIndex + direction;
        if (newIndex >= 0 && newIndex < mixedQuestions.length) {
            this.currentQuestionIndex = newIndex;
            this.loadQuestion(this.currentQuestionIndex);
        }
        this.updateNavigationState();
    }

    updateNavigationState() {
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const counter = document.querySelector('.question-counter');
        
        prevBtn.disabled = this.currentQuestionIndex === 0;
        nextBtn.disabled = this.currentQuestionIndex === mixedQuestions.length - 1;
        counter.textContent = `Question ${this.currentQuestionIndex + 1}/${mixedQuestions.length}`;
    }

    loadQuestion(index) {
        const question = mixedQuestions[index];
        if (!question) return;

        document.getElementById('questionText').textContent = question.question;
        document.getElementById('hintText').textContent = `💡 Hint: ${question.hint}`;
        this.editor.setValue(question.initialCode);
        this.updateNavigationState();
    }

    runCode() {
        try {
            this.setLoading(true);
            const code = this.editor.getValue();
            
            const outputFrame = document.getElementById('outputFrame');
            const outputDoc = outputFrame.contentDocument || outputFrame.contentWindow.document;
            
            // Create a clean document with isolated script execution
            outputDoc.open();
            outputDoc.write(`
                <!DOCTYPE html>
                <html>
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                        <style>
                            body { 
                                font-family: system-ui, -apple-system, sans-serif;
                                padding: 1rem;
                                margin: 0;
                            }
                        </style>
                    </head>
                    <body>
                        <div class="output-container">
                            ${code}
                        </div>
                        <script>
                            // Safely execute inline scripts one at a time
                            const scripts = document.querySelectorAll('script:not([src])');
                            let scriptContent = '';
                            scripts.forEach(script => {
                                if (script.textContent) {
                                    scriptContent += script.textContent + '\\n';
                                }
                            });
                            
                            // Remove all inline scripts to prevent re-execution
                            scripts.forEach(script => script.remove());
                            
                            // Execute combined script content once
                            if (scriptContent) {
                                const newScript = document.createElement('script');
                                newScript.textContent = scriptContent;
                                document.body.appendChild(newScript);
                            }
                        </script>
                    </body>
                </html>
            `);
            outputDoc.close();
        } catch (error) {
            this.showError(error);
        } finally {
            this.setLoading(false);
        }
    }

    showError(error) {
        const outputFrame = document.getElementById('outputFrame');
        const outputDoc = outputFrame.contentDocument || outputFrame.contentWindow.document;
        
        outputDoc.open();
        outputDoc.write(`
            <div style="padding: 1rem;">
                <div style="color: #d32f2f; background: #ffebee; padding: 1rem; border-radius: 8px;">
                    <h3 style="margin: 0 0 0.5rem 0;">Runtime Error</h3>
                    <pre style="margin: 0; font-family: monospace; font-size: 0.9rem;">
                        ${error.message}
                    </pre>
                </div>
            </div>
        `);
        outputDoc.close();
    }

    setLoading(isLoading) {
        const outputSection = document.querySelector('.output-section');
        outputSection.classList.toggle('loading', isLoading);
        
        const runBtn = document.getElementById('runBtn');
        runBtn.disabled = isLoading;
        runBtn.innerHTML = isLoading ? 
            '<i class="fas fa-spinner fa-spin"></i> Running...' : 
            '<i class="fas fa-play"></i> Run Code';
    }

    askAI() {
        try {
            const code = this.editor.getValue();
            const question = mixedQuestions[this.currentQuestionIndex];
            
            // Create a fixed size pre element
            const pre = document.createElement('pre');
            pre.style.height = '400px';
            pre.style.overflow = 'auto';
            pre.innerHTML = code
                .replace(/[\u00A0-\u9999<>&]/gim, (i) => `&#${i.charCodeAt(0)};`)
                .replace(/\t/g, '    '); // Convert tabs to spaces
            
            const prompt = [
                `Question: ${question.question}`,
                '',
                'Here is my code:',
                pre.outerHTML,
                '',
                'Can you please explain what this code does and how I can improve it?'
            ].join('\n');

            // Safely set the input value
            const chatInput = document.getElementById('userInput');
            if (chatInput) {
                // Encode special characters and normalize whitespace
                chatInput.value = prompt; // Convert tabs to spaces
            }

            // Trigger chat
            const chatToggle = document.getElementById('chatToggle');
            const sendBtn = document.getElementById('sendBtn');
            
            if (chatToggle && sendBtn) {
                chatToggle.click();
                sendBtn.disabled = false;
                sendBtn.click();
            }
        } catch (error) {
            console.error('Error in askAI:', error);
            this.showError(new Error('Failed to process AI request. Please try again.'));
        }
    }

    toggleSolution() {
        const question = mixedQuestions[this.currentQuestionIndex];
        const solutionBtn = document.getElementById('solutionBtn');
        
        if (!question || !solutionBtn) return;

        const isSolutionShown = solutionBtn.classList.contains('active');
        const codeToShow = isSolutionShown ? question.initialCode : (question.solution || '');

        if (this.editor) {
            this.editor.setValue(codeToShow || '');
            solutionBtn.classList.toggle('active');
            solutionBtn.innerHTML = isSolutionShown ? 
                '<i class="fas fa-lightbulb"></i> View Solution' : 
                '<i class="fas fa-undo"></i> Reset Code';
        }
    }

    reviewCode() {
        const userCode = this.editor.getValue();
        const question = mixedQuestions[this.currentQuestionIndex];
        
        // Run both user code and solution
        const outputFrame = document.getElementById('outputFrame');
        const outputDoc = outputFrame.contentDocument || outputFrame.contentWindow.document;
        
        outputDoc.open();
        outputDoc.write(`
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; padding: 1rem;">
                <div>
                    <h3>Your Output</h3>
                    <div class="user-output">${userCode}</div>
                </div>
                <div>
                    <h3>Expected Output</h3>
                    <div class="solution-output">${question.solution}</div>
                </div>
            </div>
            <style>
                h3 { color: #333; margin-bottom: 1rem; }
                .user-output, .solution-output {
                    padding: 1rem;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }
            </style>
        `);
        outputDoc.close();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.quiz = new CompilerQuiz();
}); 