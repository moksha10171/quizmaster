document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const navToggle = document.getElementById('navToggle');
    const navContent = document.getElementById('navContent');
    const navbar = document.querySelector('.navbar');
    const navLinks = document.querySelectorAll('.nav-links a');
    const body = document.body;
    const scrollToTopBtn = document.getElementById('scrollToTop');

    // Navigation Functions
    const toggleMobileMenu = (e) => {
        e.preventDefault();
        e.stopPropagation();
        navToggle.classList.toggle('active');
        navContent.classList.toggle('active');
        
        // Toggle body scroll
        if (navContent.classList.contains('active')) {
            body.style.overflow = 'hidden';
        } else {
            body.style.overflow = '';
        }
    };

    // Close mobile menu when clicking outside
    const closeMobileMenu = (e) => {
        if (navContent.classList.contains('active') && 
            !navContent.contains(e.target) && 
            !navToggle.contains(e.target)) {
            navToggle.classList.remove('active');
            navContent.classList.remove('active');
            body.style.overflow = '';
        }
    };

    // Handle nav link clicks
    const handleNavLinkClick = () => {
        if (window.innerWidth <= 768) {
            navToggle.classList.remove('active');
            navContent.classList.remove('active');
            body.style.overflow = '';
        }
    };

    // Smart Navbar Scroll
    let lastScroll = 0;
    const handleScroll = () => {
        const currentScroll = window.pageYOffset;
        
        // Add scrolled class to navbar
        if (currentScroll > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        // Show/hide scroll to top button
        if (currentScroll > 300) {
            scrollToTopBtn.classList.add('visible');
        } else {
            scrollToTopBtn.classList.remove('visible');
        }

        lastScroll = currentScroll;
    };

    // Scroll to top
    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    // Event Listeners
    navToggle.addEventListener('click', toggleMobileMenu);
    document.addEventListener('click', closeMobileMenu);
    navLinks.forEach(link => link.addEventListener('click', handleNavLinkClick));
    window.addEventListener('scroll', handleScroll);
    scrollToTopBtn.addEventListener('click', scrollToTop);

    // Initialize navbar state
    handleScroll();
});
