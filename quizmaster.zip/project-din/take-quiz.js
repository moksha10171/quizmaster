// Constants and State Management
const API_BASE_URL = 'https://quizapi.io/api/v1/questions';
const API_KEY = 'YN6ZP5KTV1oHumagAsjFA7xyfBEGaRxkMlbMWg6V';

class QuizManager {
    constructor() {
        this.state = {
            questions: [],
            currentIndex: 0,
            userAnswers: new Map(),
            timeRemaining: 1800, // 30 minutes in seconds
            timerInterval: null,
            isSubmitted: false,
            performanceChart: null,
            isLoading: false
        };
        
        this.elements = {};
        this.config = null;
        this.initializeConfig();
        this.wordDefinition = new WordDefinition(); // Initialize but don't enable yet
    }

    initializeConfig() {
        try {
            const configString = localStorage.getItem('quizConfig');
            if (!configString) {
                throw new Error('Quiz configuration not found');
            }

            const config = JSON.parse(configString);
            if (!config.category || !config.difficulty || !config.questionCount) {
                throw new Error('Invalid quiz configuration');
            }

            this.config = config;
        } catch (error) {
            this.handleError(error);
        }
    }

    updateTimerDisplay() {
        if (!this.elements.timer) return;
        
        const minutes = Math.floor(this.state.timeRemaining / 60);
        const seconds = this.state.timeRemaining % 60;
        this.elements.timer.textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }

    startTimer() {
        this.updateTimerDisplay();
        this.state.timerInterval = setInterval(() => {
            if (this.state.timeRemaining > 0) {
                this.state.timeRemaining--;
                this.updateTimerDisplay();
            } else {
                this.submitQuiz();
            }
        }, 1000);
    }

    updateQuizHeader() {
        if (this.elements.title) {
            this.elements.title.textContent = `${this.config.category} Quiz`;
        }
        if (this.elements.difficulty) {
            this.elements.difficulty.textContent = this.config.difficulty;
        }
        if (this.elements.questionNumber) {
            this.elements.questionNumber.textContent = 
                `${this.state.currentIndex + 1}/${this.state.questions.length}`;
        }
        this.updateTimerDisplay();
    }

    async fetchQuestions() {
        try {
            const params = new URLSearchParams({
                apiKey: API_KEY,
                category: this.config.category.toLowerCase(),
                difficulty: this.config.difficulty.toLowerCase(),
                limit: this.config.questionCount.toString()
            });

            const response = await fetch(`${API_BASE_URL}?${params}`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const questions = await response.json();
            
            if (!Array.isArray(questions) || questions.length === 0) {
                throw new Error('No questions available');
            }

            this.state.questions = questions;
            this.updateQuizHeader();
        } catch (error) {
            console.error('Error fetching questions:', error);
            throw new Error(`Failed to load questions: ${error.message}`);
        }
    }

    loadQuestion(index) {
        const question = this.state.questions[index];
        if (!question) return;

        // Update question text and number
        this.elements.questionText.textContent = question.question;
        this.elements.currentQuestionLabel.textContent = `Question ${index + 1}`;
        this.elements.questionNumber.textContent = `${index + 1}/${this.state.questions.length}`;

        // Clear existing options
        this.elements.optionsGrid.innerHTML = '';

        // Add new options
        Object.entries(question.answers)
            .filter(([key, value]) => value !== null)
            .forEach(([key, value], i) => {
                const optionCard = this.createOptionCard(key, value, i);
                this.elements.optionsGrid.appendChild(optionCard);
            });

        // Update navigation buttons
        this.elements.prevBtn.disabled = index === 0;
        this.elements.nextBtn.disabled = index === this.state.questions.length - 1;

        // Update progress
        this.updateProgress();
    }

    createOptionCard(key, value, index) {
        const card = document.createElement('div');
        card.className = 'option-card';
        card.setAttribute('role', 'radio');
        card.setAttribute('aria-checked', 'false');
        card.setAttribute('tabindex', '0');
        
        const isSelected = this.state.userAnswers.get(this.state.currentIndex) === key;
        if (isSelected) {
            card.classList.add('selected');
            card.setAttribute('aria-checked', 'true');
        }

        card.innerHTML = `
            <div class="option-content">
                <span class="option-marker" aria-hidden="true">${String.fromCharCode(65 + index)}</span>
                <span class="option-text">${value}</span>
            </div>
        `;

        card.addEventListener('click', () => this.selectAnswer(key));
        card.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.selectAnswer(key);
            }
        });

        return card;
    }

    selectAnswer(key) {
        this.state.userAnswers.set(this.state.currentIndex, key);
        this.loadQuestion(this.state.currentIndex);
        this.updateProgress();
    }

    updateProgress() {
        const totalQuestions = this.state.questions.length;
        const answered = this.state.userAnswers.size;

        // Update counts
        if (this.elements.answeredCount) {
            this.elements.answeredCount.textContent = answered;
        }
        if (this.elements.remainingCount) {
            this.elements.remainingCount.textContent = totalQuestions - answered;
        }

        // Update progress bar
        if (this.elements.progressBar) {
            const progress = (answered / totalQuestions) * 100;
            this.elements.progressBar.style.width = `${progress}%`;
        }
    }

    handleError(error) {
        console.error('Quiz error:', error);
        
        const errorHtml = `
            <div class="error-container">
                <div class="error-content">
                    <i class="fas fa-exclamation-circle"></i>
                    <h3>Error</h3>
                    <p>${error.message}</p>
                    <div class="error-actions">
                        <button onclick="location.reload()" class="retry-btn">
                            <i class="fas fa-redo"></i> Try Again
                        </button>
                        <button onclick="window.location.href='index.html'" class="home-btn">
                            <i class="fas fa-home"></i> Return Home
                        </button>
                    </div>
                </div>
            </div>
        `;

        if (this.elements.quizInterface) {
            this.elements.quizInterface.innerHTML = errorHtml;
            this.elements.quizInterface.style.display = 'block';
        }

        if (this.elements.loader) {
            this.elements.loader.style.display = 'none';
        }

        this.showNotification(error.message);
    }

    async initialize() {
        try {
            // Load all required DOM elements
            await this.loadElements();
            
            // Show loader
            if (this.elements.loader) {
                this.elements.loader.style.display = 'flex';
            }

            // Fetch questions from API
            await this.fetchQuestions();

            // Setup event listeners
            this.setupEventListeners();

            // Load first question
            this.loadQuestion(0);

            // Start timer
            this.startTimer();

            // Hide loader and show quiz interface
            if (this.elements.loader) {
                this.elements.loader.style.display = 'none';
            }
            if (this.elements.quizInterface) {
                this.elements.quizInterface.style.display = 'block';
            }

        } catch (error) {
            console.error('Failed to initialize quiz:', error);
            this.handleError(error);
        }
    }

    async loadElements() {
        this.elements = {
            loader: document.getElementById('quizLoader'),
            quizInterface: document.getElementById('quizInterface'),
            title: document.getElementById('quizTitle'),
            difficulty: document.getElementById('difficulty'),
            timer: document.getElementById('timer'),
            questionNumber: document.getElementById('questionNumber'),
            questionText: document.getElementById('questionText'),
            optionsGrid: document.getElementById('optionsGrid'),
            currentQuestionLabel: document.getElementById('currentQuestionLabel'),
            progressBar: document.getElementById('quizProgress'),
            answeredCount: document.getElementById('answeredCount'),
            remainingCount: document.getElementById('remainingCount'),
            prevBtn: document.getElementById('prevBtn'),
            nextBtn: document.getElementById('nextBtn'),
            submitBtn: document.getElementById('submitBtn')
        };

        // Validate required elements
        const missingElements = Object.entries(this.elements)
            .filter(([key, element]) => !element)
            .map(([key]) => key);

        if (missingElements.length > 0) {
            throw new Error(`Missing required elements: ${missingElements.join(', ')}`);
        }
    }

    setupEventListeners() {
        // Navigation buttons
        this.elements.prevBtn.addEventListener('click', () => this.navigateQuestion(-1));
        this.elements.nextBtn.addEventListener('click', () => this.navigateQuestion(1));
        this.elements.submitBtn.addEventListener('click', () => this.submitQuiz());

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') this.navigateQuestion(-1);
            if (e.key === 'ArrowRight') this.navigateQuestion(1);
        });
    }

    navigateQuestion(direction) {
        const newIndex = this.state.currentIndex + direction;
        if (newIndex >= 0 && newIndex < this.state.questions.length) {
            this.state.currentIndex = newIndex;
            this.loadQuestion(newIndex);
        }
    }

    async submitQuiz() {
        try {
            if (this.state.isLoading) return;
            this.state.isLoading = true;

            clearInterval(this.state.timerInterval);
            const results = this.calculateResults();
            
            // Show loader while preparing results
            const loader = document.createElement('div');
            loader.className = 'results-loader';
            loader.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Preparing your results...';
            document.body.appendChild(loader);

            try {
                await this.updateResultModal(results);
                this.generatePerformanceChart(results);
                
                this.elements.quizInterface.style.display = 'none';
                const resultModal = document.getElementById('resultModal');
                if (resultModal) {
                    resultModal.classList.add('active');
                    
                    // Enable word definition after quiz submission
                    this.wordDefinition.enable();

                    // Limit word definition to review section
                    document.addEventListener('mouseup', (e) => {
                        const reviewSection = document.querySelector('.review-section');
                        if (!reviewSection?.contains(e.target)) {
                            this.wordDefinition?.hideContainer();
                        }
                    });
                }
                
                this.setupResultActions();
                this.state.isSubmitted = true;
                this.updateButtonStates();
                
                this.showNotification('Quiz submitted successfully!', 'success');
            } finally {
                loader.remove();
            }
        } catch (error) {
            console.error('Error submitting quiz:', error);
            this.showNotification('Failed to submit quiz. Please try again.');
            this.handleError(error);
        } finally {
            this.state.isLoading = false;
        }
    }

    setupResultActions() {
        // Review Answers Button
        document.getElementById('reviewBtn').addEventListener('click', () => {
            this.showAnswerReview();
        });

        // Share Results Button
        document.getElementById('shareBtn').addEventListener('click', () => {
            this.shareResults();
        });

        // Download Certificate Button
        document.getElementById('downloadBtn').addEventListener('click', () => {
            this.downloadCertificate();
        });
    }

    async showAnswerReview() {
        const reviewModal = document.createElement('div');
        reviewModal.className = 'review-modal active';
        
        let reviewContent = `
            <div class="review-content">
                <div class="review-header">
                    <h3>Answer Review</h3>
                    <button class="close-review-btn">×</button>
                </div>
                <div class="review-questions">`;

        this.state.questions.forEach((question, index) => {
            const userAnswer = this.state.userAnswers.get(index);
            const isCorrect = userAnswer && question.correct_answers[`${userAnswer}_correct`] === 'true';
            const correctAnswer = this.getCorrectAnswer(question);
            
            reviewContent += `
                <div class="review-question ${isCorrect ? 'correct' : 'incorrect'}">
                    <div class="question-status">
                        <div class="status-info">
                            <i class="fas ${isCorrect ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                            Question ${index + 1}
                        </div>
                        <button class="ask-ai-btn" 
                            data-question="${encodeURIComponent(question.question)}"
                            data-user-answer="${encodeURIComponent(userAnswer ? question.answers[userAnswer] : 'Not answered')}"
                            data-correct-answer="${encodeURIComponent(correctAnswer)}"
                            data-explanation="${encodeURIComponent(question.explanation || 'No explanation available.')}">
                            <i class="fas fa-robot"></i> Ask AI
                        </button>
                    </div>
                    <p class="question-text">${question.question}</p>
                    <div class="answers-review">`;

            Object.entries(question.answers)
                .filter(([key, value]) => value !== null)
                .forEach(([key, value]) => {
                    const isUserAnswer = key === userAnswer;
                    const isCorrectAnswer = question.correct_answers[`${key}_correct`] === 'true';
                    
                    reviewContent += `
                        <div class="answer-item ${isUserAnswer ? 'user-answer' : ''} ${isCorrectAnswer ? 'correct-answer' : ''}">
                            <span class="answer-marker">
                                ${isUserAnswer ? '<i class="fas fa-user"></i>' : ''}
                                ${isCorrectAnswer ? '<i class="fas fa-check"></i>' : ''}
                            </span>
                            <span class="answer-text">${value}</span>
                        </div>`;
                });

            reviewContent += `
                    </div>
                    <div class="question-explanation">
                        <strong>Explanation:</strong>
                        <p>${question.explanation || 'No explanation available.'}</p>
                    </div>
                </div>`;
        });

        reviewContent += `
            </div>
        </div>`;

        reviewModal.innerHTML = reviewContent;
        document.body.appendChild(reviewModal);

        // Add event listeners for Ask AI buttons
        reviewModal.querySelectorAll('.ask-ai-btn').forEach(button => {
            button.addEventListener('click', () => {
                const questionData = {
                    question: decodeURIComponent(button.dataset.question),
                    userAnswer: decodeURIComponent(button.dataset.userAnswer),
                    correctAnswer: decodeURIComponent(button.dataset.correctAnswer),
                    explanation: decodeURIComponent(button.dataset.explanation)
                };
                this.askAIAboutQuestion(questionData);
            });
        });

        // Close button functionality
        reviewModal.querySelector('.close-review-btn').addEventListener('click', () => {
            reviewModal.remove();
        });
    }

    askAIAboutQuestion(questionData) {
        const chatInput = document.querySelector('#userInput');
        const sendButton = document.querySelector('#sendBtn');
        const chatToggle = document.querySelector('#chatToggle');
        
        if (chatInput && sendButton && chatToggle) {
            const prompt = `Please explain this question and its solution:

Question: ${questionData.question}

My Answer: ${questionData.userAnswer}
Correct Answer: ${questionData.correctAnswer}
Official Explanation: ${questionData.explanation}

Can you provide a detailed explanation of:
1. Why the correct answer is right
2. Why my answer was wrong (if applicable)
3. The key concepts involved
4. How to remember this for future reference`;
            
            // Set the input value and trigger the chat
            chatInput.value = prompt;
            sendButton.removeAttribute('disabled');
            sendButton.click();
            
            // Open chat if it's not already open
            if (!document.querySelector('.chat-widget.active')) {
                chatToggle.click();
            }
        }
    }

    async shareResults() {
        const results = this.calculateResults();
        const shareData = {
            title: 'My Quiz Results',
            text: `I scored ${results.score}% on the ${this.config.category} quiz! Try it yourself!`,
            url: window.location.href
        };

        try {
            if (navigator.share) {
                await navigator.share(shareData);
            } else {
                // Fallback for browsers that don't support Web Share API
                const shareModal = document.createElement('div');
                shareModal.className = 'share-modal active';
                shareModal.innerHTML = `
                    <div class="share-content">
                        <h3>Share Your Results</h3>
                        <div class="share-buttons">
                            <button onclick="window.open('https://twitter.com/intent/tweet?text=${encodeURIComponent(shareData.text)}')">
                                <i class="fab fa-twitter"></i> Twitter
                            </button>
                            <button onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}')">
                                <i class="fab fa-facebook"></i> Facebook
                            </button>
                            <button onclick="window.open('https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}')">
                                <i class="fab fa-linkedin"></i> LinkedIn
                            </button>
                        </div>
                        <button class="close-share-btn">Close</button>
                    </div>
                `;
                document.body.appendChild(shareModal);

                shareModal.querySelector('.close-share-btn').addEventListener('click', () => {
                    shareModal.remove();
                });
            }
        } catch (error) {
            console.error('Error sharing results:', error);
        }
    }

    async downloadCertificate() {
        try {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF({
                orientation: 'landscape',
                unit: 'mm',
                format: 'a4'
            });

            const results = this.calculateResults();
            const dateCompleted = new Date().toLocaleDateString();

            // Add certificate design
            doc.setFillColor(230, 230, 230);
            doc.rect(0, 0, 297, 210, 'F');
            
            // Add border
            doc.setDrawColor(0);
            doc.setLineWidth(1);
            doc.rect(10, 10, 277, 190);

            // Add header
            doc.setFont('helvetica', 'bold');
            doc.setFontSize(40);
            doc.setTextColor(44, 62, 80);
            doc.text('Certificate of Completion', 148.5, 50, { align: 'center' });

            // Add content
            doc.setFontSize(20);
            doc.text('This is to certify that', 148.5, 80, { align: 'center' });
            
            doc.setFont('helvetica', 'italic');
            doc.setFontSize(30);
            doc.text('Quiz Participant', 148.5, 100, { align: 'center' });

            doc.setFont('helvetica', 'normal');
            doc.setFontSize(20);
            doc.text(`has completed the ${this.config.category} Quiz`, 148.5, 120, { align: 'center' });
            doc.text(`with a score of ${results.score}%`, 148.5, 140, { align: 'center' });
            
            doc.setFontSize(15);
            doc.text(`Completed on ${dateCompleted}`, 148.5, 160, { align: 'center' });

            // Save the PDF
            doc.save('quiz-certificate.pdf');
        } catch (error) {
            console.error('Error generating certificate:', error);
            this.handleError(new Error('Failed to generate certificate'));
        }
    }

    generatePerformanceChart(results) {
        try {
            const performanceCanvas = document.getElementById('performanceChart');
            if (!performanceCanvas) {
                console.error('Performance chart canvas not found');
                return;
            }

            const ctx = performanceCanvas.getContext('2d');
            
            // Destroy existing chart if it exists
            if (this.state.performanceChart) {
                this.state.performanceChart.destroy();
            }

            // Calculate percentages
            const correctPercentage = (results.correct / results.totalQuestions) * 100;
            const incorrectPercentage = ((results.answered - results.correct) / results.totalQuestions) * 100;
            const unansweredPercentage = ((results.totalQuestions - results.answered) / results.totalQuestions) * 100;

            this.state.performanceChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Correct', 'Incorrect', 'Unanswered'],
                    datasets: [{
                        data: [
                            correctPercentage.toFixed(1),
                            incorrectPercentage.toFixed(1),
                            unansweredPercentage.toFixed(1)
                        ],
                        backgroundColor: [
                            '#4CAF50',  // Green for correct
                            '#f44336',  // Red for incorrect
                            '#9e9e9e'   // Grey for unanswered
                        ],
                        borderWidth: 0,
                        borderRadius: 5
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                padding: 20,
                                usePointStyle: true,
                                pointStyle: 'circle'
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return `${context.label}: ${context.raw}%`;
                                }
                            }
                        }
                    },
                    cutout: '70%'
                }
            });
        } catch (error) {
            console.error('Error generating performance chart:', error);
            this.showNotification('Failed to generate performance chart');
        }
    }

    calculateResults() {
        const totalQuestions = this.state.questions.length;
        const answered = this.state.userAnswers.size;
        let correct = 0;
        let topicStats = new Map();

        // Calculate correct answers and topic statistics
        this.state.userAnswers.forEach((answer, index) => {
            const question = this.state.questions[index];
            const isCorrect = question.correct_answers[`${answer}_correct`] === 'true';
            
            // Track topic statistics
            const topic = question.category || 'General';
            if (!topicStats.has(topic)) {
                topicStats.set(topic, { total: 0, correct: 0 });
            }
            const stats = topicStats.get(topic);
            stats.total++;
            if (isCorrect) {
                stats.correct++;
                correct++;
            }
        });

        // Calculate score and accuracy
        const score = Math.round((correct / totalQuestions) * 100);
        const accuracy = answered > 0 ? Math.round((correct / answered) * 100) : 0;
        const timeTaken = 1800 - this.state.timeRemaining;

        return {
            score,
            correct,
            totalQuestions,
            answered,
            accuracy,
            timeTaken,
            topicStats: Array.from(topicStats.entries()).map(([topic, stats]) => ({
                topic,
                percentage: Math.round((stats.correct / stats.total) * 100),
                correct: stats.correct,
                total: stats.total
            }))
        };
    }

    destroyCharts() {
        if (this.topicsChart) {
            this.topicsChart.destroy();
        }
        if (this.timeChart) {
            this.timeChart.destroy();
        }
    }

    async updateResultModal(results) {
        try {
            // Clean up existing charts first
            this.destroyCharts();

            // Update score circle
            const scoreCircle = document.querySelector('.score-circle');
            if (scoreCircle) {
                scoreCircle.style.setProperty('--progress', `${results.score}%`);
                const scoreText = scoreCircle.querySelector('.score-text');
                if (scoreText) {
                    scoreText.textContent = `${results.score}%`;
                }
            }

            // Update statistics cards
            const statsContainer = document.querySelector('.results-stats');
            if (statsContainer) {
                statsContainer.innerHTML = `
                    <div class="stat-card">
                        <i class="fas fa-check-circle"></i>
                        <div class="stat-info">
                            <span class="stat-label">Correct Answers</span>
                            <span class="stat-value correct">${results.correct}/${results.totalQuestions}</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-clock"></i>
                        <div class="stat-info">
                            <span class="stat-label">Time Taken</span>
                            <span class="stat-value">${Math.floor(results.timeTaken / 60)}:${String(results.timeTaken % 60).padStart(2, '0')}</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-bullseye"></i>
                        <div class="stat-info">
                            <span class="stat-label">Accuracy</span>
                            <span class="stat-value">${results.accuracy}%</span>
                        </div>
                    </div>`;
            }

            // Topic Breakdown Chart
            const topicsChart = document.getElementById('topicsChart');
            if (topicsChart) {
                const ctx = topicsChart.getContext('2d');
                this.topicsChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: results.topicStats.map(stat => stat.topic),
                        datasets: [{
                            label: 'Performance by Topic',
                            data: results.topicStats.map(stat => stat.percentage),
                            backgroundColor: 'rgba(54, 162, 235, 0.8)',
                            borderRadius: 8
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        animation: {
                            duration: 1000
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 100,
                                grid: {
                                    display: false
                                },
                                ticks: {
                                    callback: value => `${value}%`
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                callbacks: {
                                    label: (context) => {
                                        const stat = results.topicStats[context.dataIndex];
                                        return `Score: ${stat.correct}/${stat.total} (${stat.percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            // Time Analysis Chart
            const timeChart = document.getElementById('timeChart');
            if (timeChart) {
                const ctx = timeChart.getContext('2d');
                this.timeChart = new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Time Used', 'Time Remaining'],
                        datasets: [{
                            data: [
                                results.timeTaken,
                                Math.max(0, 1800 - results.timeTaken)
                            ],
                            backgroundColor: [
                                'rgba(54, 162, 235, 0.9)',
                                'rgba(238, 238, 238, 0.5)'
                            ],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        animation: {
                            duration: 1000,
                            animateRotate: true
                        },
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    padding: 20,
                                    usePointStyle: true,
                                    pointStyle: 'circle',
                                    font: {
                                        size: 14
                                    }
                                }
                            },
                            tooltip: {
                                callbacks: {
                                    label: (context) => {
                                        const minutes = Math.floor(context.raw / 60);
                                        const seconds = context.raw % 60;
                                        const percentage = ((context.raw / 1800) * 100).toFixed(1);
                                        return `${context.label}: ${minutes}m ${seconds}s (${percentage}%)`;
                                    }
                                }
                            },
                            title: {
                                display: true,
                                text: 'Time Distribution',
                                padding: {
                                    bottom: 15
                                },
                                font: {
                                    size: 16,
                                    weight: 'bold'
                                }
                            }
                        },
                        cutout: '70%'
                    }
                });
            }

        } catch (error) {
            console.error('Error updating review section:', error);
        }
    }
    // Helper method to get correct answer text
    getCorrectAnswer(question) {
        const correctAnswerKey = Object.keys(question.correct_answers)
            .find(key => question.correct_answers[key] === 'true');
        return correctAnswerKey ? question.answers[correctAnswerKey.replace('_correct', '')] : 'Not available';
    }

    showNotification(message, type = 'error') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas ${type === 'error' ? 'fa-exclamation-circle' : 'fa-check-circle'}"></i>
                <p>${message}</p>
            </div>
        `;
        document.body.appendChild(notification);

        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    updateButtonStates() {
        // Previous button
        if (this.elements.prevBtn) {
            this.elements.prevBtn.disabled = this.state.currentIndex === 0;
        }

        // Next button
        if (this.elements.nextBtn) {
            this.elements.nextBtn.disabled = this.state.currentIndex === this.state.questions.length - 1;
        }

        // Submit button
        if (this.elements.submitBtn) {
            const hasAnsweredAll = this.state.userAnswers.size === this.state.questions.length;
            this.elements.submitBtn.disabled = !hasAnsweredAll || this.state.isSubmitted;
        }
    }

    closeResultModal() {
        const resultModal = document.getElementById('resultModal');
        if (resultModal) {
            resultModal.classList.remove('active');
            // Disable word definition when modal is closed
            this.wordDefinition?.disable();
        }
    }
}

// Initialize quiz when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    try {
        // Set default quiz configuration if not present
        if (!localStorage.getItem('quizConfig')) {
            const defaultConfig = {
                category: 'Linux',
                difficulty: 'Medium',
                questionCount: 10
            };
            localStorage.setItem('quizConfig', JSON.stringify(defaultConfig));
        }

        const quizManager = new QuizManager();
        quizManager.initialize().catch(error => {
            console.error('Failed to initialize quiz:', error);
            quizManager.handleError(error);
        });
    } catch (error) {
        console.error('Failed to start quiz:', error);
        const quizManager = new QuizManager();
        quizManager.handleError(error);
    }
});

