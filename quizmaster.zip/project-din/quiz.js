document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const timerElement = document.getElementById('timer');
    const progressBar = document.getElementById('progress');
    const options = document.querySelectorAll('.option');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const flagBtn = document.getElementById('flagBtn');

    // Quiz State
    let currentQuestion = 1;
    let totalQuestions = 20;
    let timeLeft = 1800; // 30 minutes in seconds
    let selectedAnswers = new Map();
    let flaggedQuestions = new Set();

    // Timer Function
    const startTimer = () => {
        const timer = setInterval(() => {
            timeLeft--;
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            if (timeLeft <= 0) {
                clearInterval(timer);
                submitQuiz();
            }
        }, 1000);
    };

    // Update Progress
    const updateProgress = () => {
        const progress = (currentQuestion / totalQuestions) * 100;
        progressBar.style.width = `${progress}%`;
        document.getElementById('questionCount').textContent = `${currentQuestion}/${totalQuestions}`;
    };

    // Handle Option Selection
    options.forEach(option => {
        option.addEventListener('click', () => {
            options.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
            selectedAnswers.set(currentQuestion, option.dataset.option);
        });
    });

    // Navigation Handlers
    prevBtn.addEventListener('click', () => {
        if (currentQuestion > 1) {
            currentQuestion--;
            updateProgress();
            loadQuestion(currentQuestion);
        }
    });

    nextBtn.addEventListener('click', () => {
        if (currentQuestion < totalQuestions) {
            currentQuestion++;
            updateProgress();
            loadQuestion(currentQuestion);
        } else {
            submitQuiz();
        }
    });

    // Flag Question Handler
    flagBtn.addEventListener('click', () => {
        if (flaggedQuestions.has(currentQuestion)) {
            flaggedQuestions.delete(currentQuestion);
            flagBtn.classList.remove('flagged');
        } else {
            flaggedQuestions.add(currentQuestion);
            flagBtn.classList.add('flagged');
        }
    });

    // Load Question
    const loadQuestion = (questionNumber) => {
        // Here you would typically fetch the question data from your backend
        // For now, we'll just update the UI
        const selected = selectedAnswers.get(questionNumber);
        options.forEach(option => {
            option.classList.remove('selected');
            if (selected && option.dataset.option === selected) {
                option.classList.add('selected');
            }
        });

        flagBtn.classList.toggle('flagged', flaggedQuestions.has(questionNumber));
    };

    // Submit Quiz
    const submitQuiz = () => {
        // Here you would typically send the answers to your backend
        console.log('Quiz submitted:', {
            answers: Object.fromEntries(selectedAnswers),
            flaggedQuestions: Array.from(flaggedQuestions),
            timeSpent: 1800 - timeLeft
        });
    };

    // Initialize Quiz
    updateProgress();
    startTimer();
});
