class LeaderboardManager {
    constructor() {
        this.currentPage = 1;
        this.itemsPerPage = 10;
        this.initializeElements();
        this.setupEventListeners();
        this.loadLeaderboardData();
    }

    initializeElements() {
        this.categoryFilter = document.getElementById('categoryFilter');
        this.timeFilter = document.getElementById('timeFilter');
        this.tableBody = document.querySelector('.table-body');
        this.pagination = document.querySelector('.pagination');
    }

    setupEventListeners() {
        this.categoryFilter.addEventListener('change', () => this.handleFiltersChange());
        this.timeFilter.addEventListener('change', () => this.handleFiltersChange());
        this.pagination.addEventListener('click', (e) => this.handlePagination(e));
    }

    async loadLeaderboardData() {
        try {
            // Show loading state
            this.tableBody.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-spinner fa-spin"></i>
                    <p>Loading leaderboard data...</p>
                </div>
            `;

            // Simulate API call
            const data = await this.fetchLeaderboardData();
            this.renderLeaderboard(data);
        } catch (error) {
            console.error('Error loading leaderboard:', error);
            this.showError('Failed to load leaderboard data');
        }
    }

    async fetchLeaderboardData() {
        // Use the same categories as quiz.js
        const CATEGORIES = {
            Linux: { icon: 'fab fa-linux', color: '#FCC624' },
            BASH: { icon: 'fas fa-terminal', color: '#4EAA25' },
            PHP: { icon: 'fab fa-php', color: '#777BB4' },
            Docker: { icon: 'fab fa-docker', color: '#2496ED' },
            HTML: { icon: 'fab fa-html5', color: '#E34F26' },
            MySQL: { icon: 'fas fa-database', color: '#4479A1' },
            Laravel: { icon: 'fab fa-laravel', color: '#FF2D20' },
            JavaScript: { icon: 'fab fa-js', color: '#F7DF1E' },
            Python: { icon: 'fab fa-python', color: '#3776AB' },
            React: { icon: 'fab fa-react', color: '#61DAFB' },
            'Node.js': { icon: 'fab fa-node-js', color: '#339933' },
            WordPress: { icon: 'fab fa-wordpress', color: '#21759B' },
            'Vue.js': { icon: 'fab fa-vuejs', color: '#4FC08D' }
        };

        // Simulate API response with 15 entries per category
        return new Promise(resolve => {
            setTimeout(() => {
                const players = [];
                let rank = 4; // Start after top 3

                Object.keys(CATEGORIES).forEach(category => {
                    for (let i = 0; i < 15; i++) {
                        players.push({
                            rank: rank++,
                            name: `Player ${rank}`,
                            category: category,
                            icon: CATEGORIES[category].icon,
                            iconColor: CATEGORIES[category].color,
                            quizzes: Math.floor(Math.random() * 50) + 10,
                            accuracy: `${Math.floor(Math.random() * 30) + 70}%`,
                            points: Math.floor(Math.random() * 500) + 500,
                            time: `${Math.floor(Math.random() * 50) + 10}h`
                        });
                    }
                });

                resolve({
                    players: players,
                    totalPages: Math.ceil(players.length / 10)
                });
            }, 1000);
        });
    }

    renderLeaderboard(data) {
        this.tableBody.innerHTML = data.players.map(player => `
            <div class="table-row">
                <div class="rank">
                    <span class="rank-number">#${player.rank}</span>
                </div>
                <div class="player">
                    <div class="player-icon">
                        <i class="${player.icon}" style="color: ${player.iconColor}"></i>
                    </div>
                    <span>${player.name}</span>
                </div>
                <div class="category">
                    <i class="${player.icon}"></i>
                    ${player.category}
                </div>
                <div class="quizzes">${player.quizzes}</div>
                <div class="accuracy">${player.accuracy}</div>
                <div class="time">${player.time}</div>
                <div class="points">${player.points} pts</div>
            </div>
        `).join('');

        this.updatePagination(data.totalPages);
    }

    updatePagination(totalPages) {
        const pageNumbers = document.querySelector('.page-numbers');
        pageNumbers.innerHTML = this.generatePaginationHTML(totalPages);
    }

    generatePaginationHTML(totalPages) {
        let html = '';
        const currentPage = this.currentPage;

        if (totalPages <= 5) {
            for (let i = 1; i <= totalPages; i++) {
                html += `<button class="page-btn ${i === currentPage ? 'active' : ''}">${i}</button>`;
            }
        } else {
            // First page
            html += `<button class="page-btn ${currentPage === 1 ? 'active' : ''}">1</button>`;

            // Middle pages
            if (currentPage > 3) {
                html += '<span class="ellipsis">...</span>';
            }

            for (let i = Math.max(2, currentPage - 1); i <= Math.min(totalPages - 1, currentPage + 1); i++) {
                html += `<button class="page-btn ${i === currentPage ? 'active' : ''}">${i}</button>`;
            }

            if (currentPage < totalPages - 2) {
                html += '<span class="ellipsis">...</span>';
            }

            // Last page
            html += `<button class="page-btn ${currentPage === totalPages ? 'active' : ''}">${totalPages}</button>`;
        }

        return html;
    }

    handleFiltersChange() {
        this.currentPage = 1;
        this.loadLeaderboardData();
    }

    handlePagination(event) {
        const button = event.target.closest('.page-btn');
        if (!button) return;

        if (button.dataset.page === 'prev') {
            this.currentPage = Math.max(1, this.currentPage - 1);
        } else if (button.dataset.page === 'next') {
            this.currentPage = Math.min(10, this.currentPage + 1);
        } else {
            this.currentPage = parseInt(button.textContent);
        }

        this.loadLeaderboardData();
    }

    showError(message) {
        this.tableBody.innerHTML = `
            <div class="error-state">
                <i class="fas fa-exclamation-circle"></i>
                <p>${message}</p>
                <button onclick="leaderboardManager.loadLeaderboardData()" class="retry-btn">
                    <i class="fas fa-redo"></i> Retry
                </button>
            </div>
        `;
    }
}

// Initialize leaderboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.leaderboardManager = new LeaderboardManager();
}); 