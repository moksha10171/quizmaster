// language-skills.js
class LanguageSkillsQuiz {
    constructor() {
        this.questions = {
            ielts: [
                {
                    question: "What is the maximum band score in IELTS?",
                    options: ["9.0", "10.0", "8.0", "7.0"],
                    correct: 0,
                    explanation: "The IELTS scoring system ranges from band 1 to band 9, with 9 being the highest possible score."
                },
                {
                    question: "How long is the IELTS Listening test?",
                    options: ["30 minutes", "45 minutes", "60 minutes", "40 minutes"],
                    correct: 0,
                    explanation: "The IELTS Listening test takes approximately 30 minutes, with an additional 10 minutes to transfer answers."
                },
                {
                    question: "Which IELTS Writing Task 1 requires describing visual information?",
                    options: ["Academic", "General Training", "Both", "Neither"],
                    correct: 0,
                    explanation: "IELTS Academic Writing Task 1 requires candidates to describe visual information like graphs, charts, or diagrams."
                },
                {
                    question: "How many sections are there in the IELTS Reading test?",
                    options: ["3", "4", "2", "5"],
                    correct: 0,
                    explanation: "The IELTS Reading test consists of 3 sections, with 40 questions in total."
                },
                {
                    question: "What is the total duration of the IELTS Speaking test?",
                    options: ["11-14 minutes", "15-20 minutes", "20-25 minutes", "10-12 minutes"],
                    correct: 0,
                    explanation: "The IELTS Speaking test typically lasts between 11 and 14 minutes."
                },
                {
                    question: "Which part of IELTS Speaking test involves a long turn?",
                    options: ["Part 2", "Part 1", "Part 3", "Part 4"],
                    correct: 0,
                    explanation: "Part 2 of the Speaking test requires candidates to speak for 1-2 minutes on a given topic."
                },
                {
                    question: "What is the word limit for IELTS Writing Task 2?",
                    options: ["Minimum 250 words", "Minimum 150 words", "Maximum 250 words", "No limit"],
                    correct: 0,
                    explanation: "IELTS Writing Task 2 requires a minimum of 250 words."
                },
                {
                    question: "How many speakers can you expect in IELTS Listening Section 3?",
                    options: ["2-4 speakers", "1-2 speakers", "3-5 speakers", "Only 2 speakers"],
                    correct: 0,
                    explanation: "Section 3 typically features 2-4 speakers in an academic discussion."
                },
                {
                    question: "What type of questions appears in IELTS Reading?",
                    options: ["Multiple choice", "Essay writing", "Speaking responses", "Oral presentation"],
                    correct: 0,
                    explanation: "Multiple choice questions are one of several question types in the IELTS Reading test."
                },
                {
                    question: "Which IELTS module is preferred for immigration?",
                    options: ["General Training", "Academic", "Both are same", "Neither"],
                    correct: 0,
                    explanation: "The General Training module is typically required for immigration purposes."
                },
                {
                    question: "What is the format of IELTS Writing Task 1 in General Training?",
                    options: ["Letter writing", "Graph description", "Essay writing", "Report writing"],
                    correct: 0,
                    explanation: "General Training Writing Task 1 requires writing a letter."
                },
                {
                    question: "How many questions are in IELTS Listening?",
                    options: ["40", "30", "50", "45"],
                    correct: 0,
                    explanation: "The IELTS Listening test contains 40 questions across four sections."
                },
                {
                    question: "What is assessed in IELTS Speaking Part 3?",
                    options: ["Abstract discussion", "Personal information", "Picture description", "Past experiences"],
                    correct: 0,
                    explanation: "Part 3 assesses ability to discuss abstract ideas related to Part 2 topic."
                },
                {
                    question: "How long should you spend on IELTS Writing Task 1?",
                    options: ["20 minutes", "30 minutes", "40 minutes", "60 minutes"],
                    correct: 0,
                    explanation: "It's recommended to spend about 20 minutes on Writing Task 1."
                },
                {
                    question: "What is the recommended word count for IELTS Writing Task 1?",
                    options: ["150 words minimum", "250 words minimum", "200 words minimum", "100 words minimum"],
                    correct: 0,
                    explanation: "Task 1 requires a minimum of 150 words."
                }
            ],
            toefl: [
                {
                    question: "What is the total score range for TOEFL iBT?",
                    options: ["0-120", "0-100", "0-150", "0-90"],
                    correct: 0,
                    explanation: "The TOEFL iBT test is scored on a scale of 0-120 points."
                },
                {
                    question: "How many passages are in TOEFL Reading section?",
                    options: ["3-4", "2-3", "4-5", "5-6"],
                    correct: 0,
                    explanation: "The TOEFL Reading section contains 3-4 academic passages."
                },
                {
                    question: "What type of accent can you expect in TOEFL Listening?",
                    options: ["North American", "British", "Australian", "Mixed accents"],
                    correct: 0,
                    explanation: "TOEFL primarily uses North American English accents."
                },
                {
                    question: "How many integrated writing tasks are there?",
                    options: ["1", "2", "3", "0"],
                    correct: 0,
                    explanation: "There is 1 integrated writing task combining reading and listening skills."
                },
                {
                    question: "What is the duration of TOEFL Speaking tasks?",
                    options: ["45-60 seconds each", "30-45 seconds each", "60-90 seconds each", "15-30 seconds each"],
                    correct: 0,
                    explanation: "Most TOEFL Speaking responses should be 45-60 seconds long."
                },
                {
                    question: "How many independent Speaking tasks are there?",
                    options: ["1", "2", "3", "4"],
                    correct: 0,
                    explanation: "The TOEFL iBT includes 1 independent Speaking task."
                },
                {
                    question: "What is the total test duration?",
                    options: ["About 3 hours", "About 2 hours", "About 4 hours", "About 2.5 hours"],
                    correct: 0,
                    explanation: "The complete TOEFL iBT test takes approximately 3 hours."
                },
                {
                    question: "How many questions are in each Reading passage?",
                    options: ["10", "12", "15", "8"],
                    correct: 0,
                    explanation: "Each TOEFL Reading passage has 10 questions."
                },
                {
                    question: "What type of keyboard is used in TOEFL?",
                    options: ["QWERTY", "AZERTY", "DVORAK", "Any keyboard"],
                    correct: 0,
                    explanation: "TOEFL iBT uses standard QWERTY keyboard layout."
                },
                {
                    question: "How many Listening passages are there?",
                    options: ["4-6", "2-3", "6-8", "3-5"],
                    correct: 0,
                    explanation: "The Listening section contains 4-6 passages."
                },
                {
                    question: "What is the format of the Independent Writing task?",
                    options: ["Essay", "Summary", "Letter", "Report"],
                    correct: 0,
                    explanation: "The Independent Writing task requires writing an essay."
                },
                {
                    question: "How many Speaking tasks are there in total?",
                    options: ["4", "6", "3", "5"],
                    correct: 0,
                    explanation: "The TOEFL iBT has 4 Speaking tasks."
                },
                {
                    question: "What is the scoring range for each section?",
                    options: ["0-30", "0-20", "0-25", "0-40"],
                    correct: 0,
                    explanation: "Each section is scored from 0-30 points."
                },
                {
                    question: "What type of notes are allowed during the test?",
                    options: ["Only provided paper", "Personal notebook", "Digital notes", "No notes"],
                    correct: 0,
                    explanation: "Only official scratch paper provided by the test center is allowed."
                },
                {
                    question: "How long is the break during TOEFL?",
                    options: ["10 minutes", "15 minutes", "5 minutes", "20 minutes"],
                    correct: 0,
                    explanation: "There is a 10-minute break during the test."
                }
            ],
            duolingo: [
                {
                    question: "What is the scoring range for Duolingo English Test?",
                    options: ["10-160", "0-100", "0-120", "20-180"],
                    correct: 0,
                    explanation: "The Duolingo English Test scores range from 10 to 160."
                },
                {
                    question: "How long is the Duolingo English Test?",
                    options: ["45-60 minutes", "30-45 minutes", "60-90 minutes", "90-120 minutes"],
                    correct: 0,
                    explanation: "The test typically takes 45-60 minutes to complete."
                },
                {
                    question: "What type of questions are adaptive in DET?",
                    options: ["All questions", "Only reading", "Only listening", "Only speaking"],
                    correct: 0,
                    explanation: "All questions in DET are adaptive, adjusting to test-taker's ability."
                },
                {
                    question: "How many attempts are allowed per subscription?",
                    options: ["2", "1", "3", "Unlimited"],
                    correct: 0,
                    explanation: "Test-takers get 2 attempts per subscription."
                },
                {
                    question: "What device is required for the test?",
                    options: ["Computer with camera", "Smartphone", "Tablet", "Any device"],
                    correct: 0,
                    explanation: "A computer with a working camera is required for test proctoring."
                },
                {
                    question: "How long are results valid?",
                    options: ["2 years", "1 year", "3 years", "6 months"],
                    correct: 0,
                    explanation: "Duolingo English Test results are valid for 2 years."
                },
                {
                    question: "What is unique about DET's format?",
                    options: ["Adaptive testing", "Fixed questions", "Paper-based", "Multiple choice only"],
                    correct: 0,
                    explanation: "DET uses adaptive testing technology to adjust difficulty."
                },
                {
                    question: "What security measure is used during the test?",
                    options: ["AI proctoring", "Human proctor", "No proctoring", "Group proctoring"],
                    correct: 0,
                    explanation: "DET uses AI-based proctoring to ensure test security."
                },
                {
                    question: "How are speaking responses evaluated?",
                    options: ["AI + human graders", "Only AI", "Only human graders", "Self-evaluation"],
                    correct: 0,
                    explanation: "Speaking responses are evaluated by both AI and human graders."
                },
                {
                    question: "What is included in the video interview section?",
                    options: ["Open-ended responses", "Multiple choice", "Writing only", "Reading only"],
                    correct: 0,
                    explanation: "The video interview includes open-ended speaking responses."
                },
                {
                    question: "How quickly are results available?",
                    options: ["48 hours", "24 hours", "1 week", "Immediate"],
                    correct: 0,
                    explanation: "Results are typically available within 48 hours."
                },
                {
                    question: "What type of writing tasks are included?",
                    options: ["Various short tasks", "One long essay", "Letter writing", "Report writing"],
                    correct: 0,
                    explanation: "DET includes various short writing tasks rather than one long essay."
                },
                {
                    question: "How is vocabulary tested in DET?",
                    options: ["Multiple formats", "Only definitions", "Only synonyms", "Only in context"],
                    correct: 0,
                    explanation: "Vocabulary is tested through multiple formats and approaches."
                },
                {
                    question: "What is the retake waiting period?",
                    options: ["14 days", "7 days", "30 days", "No waiting"],
                    correct: 0,
                    explanation: "Test-takers must wait 14 days between attempts."
                },
                {
                    question: "How many institutions can receive scores?",
                    options: ["Unlimited", "5", "10", "3"],
                    correct: 0,
                    explanation: "Scores can be sent to unlimited institutions at no extra cost."
                }
            ]
        };

        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers = new Map();
        this.hasAnswered = false;

        this.learningContent = {
            ielts: {
                theory: `
                    <h4>IELTS Exam Preparation</h4>
                    
                    <h5>1. Listening Skills</h5>
                    <ul>
                        <li><strong>Section Types</strong>
                            <ul>
                                <li>Social situations - Everyday conversations and social contexts</li>
                                <li>Work situations - Professional and workplace dialogues</li>
                                <li>Academic discussions - Student-tutor conversations, group work</li>
                                <li>Academic lectures - Extended academic speech on specific topics</li>
                            </ul>
                        </li>
                        <li><strong>Question Types</strong>
                            <ul>
                                <li>Multiple choice - Select best answer from options</li>
                                <li>Form completion - Fill in forms with heard information</li>
                                <li>Note completion - Complete notes with key details</li>
                                <li>Matching - Match related pieces of information</li>
                                <li>Labeling - Label diagrams or maps</li>
                                <li>Short answer - Write brief responses to questions</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>2. Reading Skills</h5>
                    <ul>
                        <li><strong>Academic Texts</strong>
                            <ul>
                                <li>Scientific articles - Research papers and studies</li>
                                <li>Academic journals - Scholarly publications</li>
                                <li>Complex arguments - Opinion pieces and debates</li>
                                <li>Technical descriptions - Processes and systems</li>
                                <li>Historical accounts - Past events and developments</li>
                            </ul>
                        </li>
                        <li><strong>Reading Strategies</strong>
                            <ul>
                                <li>Skimming - Quick overview of main ideas</li>
                                <li>Scanning - Finding specific information</li>
                                <li>Detailed reading - In-depth comprehension</li>
                                <li>Inference skills - Understanding implied meaning</li>
                                <li>Vocabulary in context - Understanding words from context</li>
                                <li>Reference tracking - Following pronouns and references</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>3. Writing Skills</h5>
                    <ul>
                        <li><strong>Task 1</strong>
                            <ul>
                                <li>Data interpretation - Understanding graphs and charts</li>
                                <li>Process description - Explaining steps and stages</li>
                                <li>Graph analysis - Analyzing trends and patterns</li>
                                <li>Map description - Describing spatial information</li>
                                <li>Diagram explanation - Breaking down visual information</li>
                            </ul>
                        </li>
                        <li><strong>Task 2</strong>
                            <ul>
                                <li>Essay structure - Introduction, body, conclusion</li>
                                <li>Argument development - Supporting ideas with evidence</li>
                                <li>Academic style - Formal language and tone</li>
                                <li>Coherence and cohesion - Logical flow of ideas</li>
                                <li>Critical thinking - Analyzing different perspectives</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>4. Speaking Skills</h5>
                    <ul>
                        <li><strong>Interview Format</strong>
                            <ul>
                                <li>Personal questions and responses</li>
                                <li>Familiar topic discussions</li>
                                <li>Opinion expression</li>
                            </ul>
                        </li>
                        <li><strong>Cue Card Speaking</strong>
                            <ul>
                                <li>Topic development</li>
                                <li>Time management</li>
                                <li>Fluency practice</li>
                            </ul>
                        </li>
                        <li><strong>Discussion Skills</strong>
                            <ul>
                                <li>Abstract topic handling</li>
                                <li>Extended responses</li>
                                <li>Analytical thinking</li>
                            </ul>
                        </li>
                    </ul>
                `,
                examples: `
                    <h4>IELTS Practice Examples</h4>

                    <h5>1. Listening Example</h5>
                    <div class="example-box">
                        <p><strong>Audio Transcript:</strong> "The library is open from 9 AM to 8 PM on weekdays, 10 AM to 6 PM on Saturdays, and is closed on Sundays."</p>
                        <p><strong>Question:</strong> Complete the library schedule:</p>
                        <ul>
                            <li>Weekdays: ____ to ____</li>
                            <li>Saturdays: ____ to ____</li>
                            <li>Sundays: ____</li>
                        </ul>
                    </div>

                    <h5>2. Reading Example</h5>
                    <div class="example-box">
                        <p><strong>Text Extract:</strong></p>
                        <p>"Recent studies suggest that sleep patterns significantly impact cognitive performance..."</p>
                        <p><strong>Question Type:</strong> True/False/Not Given</p>
                        <ul>
                            <li>Sleep affects mental abilities</li>
                            <li>All people need exactly 8 hours of sleep</li>
                        </ul>
                    </div>

                    <h5>3. Writing Example</h5>
                    <div class="example-box">
                        <p><strong>Task 1:</strong> Describe the graph showing global temperature changes from 1900-2000.</p>
                        <p><strong>Sample Response Structure:</strong></p>
                        <ul>
                            <li>Introduction: Overview of data</li>
                            <li>Key trends identification</li>
                            <li>Specific details and figures</li>
                            <li>Summary of main patterns</li>
                        </ul>
                    </div>
                `,
                practice: `
                    <h4>IELTS Practice Exercises</h4>

                    <h5>1. Listening Practice</h5>
                    <div class="practice-exercise">
                        <p><strong>Exercise 1:</strong> Note Completion</p>
                        <audio controls src="path_to_audio"></audio>
                        <p>Complete the notes while listening:</p>
                        <form class="practice-form">
                            <input type="text" placeholder="Speaker's name">
                            <input type="text" placeholder="Main topic">
                            <input type="text" placeholder="Key points">
                        </form>
                    </div>

                    <h5>2. Reading Practice</h5>
                    <div class="practice-exercise">
                        <p><strong>Exercise 2:</strong> Matching Headings</p>
                        <p>Match these headings to paragraphs A-C:</p>
                        <ol>
                            <li>Environmental Impact</li>
                            <li>Historical Background</li>
                            <li>Future Predictions</li>
                        </ol>
                    </div>

                    <h5>3. Writing Practice</h5>
                    <div class="practice-exercise">
                        <p><strong>Task:</strong> Write a response to this statement:</p>
                        <p>"Technology has made communication easier but less meaningful."</p>
                        <textarea rows="10" placeholder="Write your response here..."></textarea>
                    </div>
                `
            },
            toefl: {
                theory: `
                    <h4>TOEFL Exam Preparation</h4>

                    <h5>1. Reading Section</h5>
                    <ul>
                        <li><strong>Academic Reading Skills</strong>
                            <ul>
                                <li>Understanding academic texts</li>
                                <li>Identifying main ideas</li>
                                <li>Recognizing supporting details</li>
                                <li>Making inferences</li>
                            </ul>
                        </li>
                        <li><strong>Question Types</strong>
                            <ul>
                                <li>Factual information</li>
                                <li>Negative factual information</li>
                                <li>Inference</li>
                                <li>Rhetorical purpose</li>
                                <li>Vocabulary in context</li>
                                <li>Reference</li>
                                <li>Sentence simplification</li>
                                <li>Insert text</li>
                                <li>Prose summary</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>2. Listening Section</h5>
                    <ul>
                        <li><strong>Lecture Types</strong>
                            <ul>
                                <li>Academic lectures</li>
                                <li>Campus conversations</li>
                                <li>Student discussions</li>
                            </ul>
                        </li>
                        <li><strong>Skills Tested</strong>
                            <ul>
                                <li>Understanding main ideas</li>
                                <li>Identifying details</li>
                                <li>Understanding organization</li>
                                <li>Understanding purpose</li>
                                <li>Making connections</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>3. Speaking Section</h5>
                    <ul>
                        <li><strong>Independent Tasks</strong>
                            <ul>
                                <li>Personal preference</li>
                                <li>Choice questions</li>
                                <li>Opinion tasks</li>
                            </ul>
                        </li>
                        <li><strong>Integrated Tasks</strong>
                            <ul>
                                <li>Reading-Listening-Speaking</li>
                                <li>Listening-Speaking</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>4. Writing Section</h5>
                    <ul>
                        <li><strong>Integrated Writing</strong>
                            <ul>
                                <li>Reading-Listening integration</li>
                                <li>Summary skills</li>
                                <li>Comparison skills</li>
                            </ul>
                        </li>
                        <li><strong>Independent Writing</strong>
                            <ul>
                                <li>Essay organization</li>
                                <li>Thesis development</li>
                                <li>Supporting examples</li>
                            </ul>
                        </li>
                    </ul>
                `,
                examples: `
                    <h4>TOEFL Practice Examples</h4>

                    <h5>1. Reading Example</h5>
                    <div class="example-box">
                        <p><strong>Academic Text:</strong></p>
                        <p>"Photosynthesis is the process by which plants convert light energy into chemical energy..."</p>
                        <p><strong>Questions:</strong></p>
                        <ul>
                            <li>What is the main purpose of photosynthesis?</li>
                            <li>Which sentence best summarizes the process?</li>
                        </ul>
                    </div>

                    <h5>2. Speaking Example</h5>
                    <div class="example-box">
                        <p><strong>Independent Speaking Task:</strong></p>
                        <p>"Describe a memorable teacher you had and explain why they were memorable."</p>
                        <p><strong>Response Structure:</strong></p>
                        <ul>
                            <li>Introduction (5 seconds)</li>
                            <li>Main points (30 seconds)</li>
                            <li>Conclusion (10 seconds)</li>
                        </ul>
                    </div>
                `,
                practice: `
                    <h4>TOEFL Practice Exercises</h4>

                    <h5>1. Reading Practice</h5>
                    <div class="practice-exercise">
                        <p><strong>Read the passage and answer:</strong></p>
                        <div class="reading-passage">
                            [Academic passage about climate change]
                        </div>
                        <div class="questions">
                            <p>1. What is the main idea?</p>
                            <p>2. Which paragraph discusses solutions?</p>
                        </div>
                    </div>

                    <h5>2. Speaking Practice</h5>
                    <div class="practice-exercise">
                        <p><strong>Task:</strong> Prepare a 45-second response:</p>
                        <p>"What is your favorite season and why?"</p>
                        <button class="record-button">Record Response</button>
                    </div>
                `
            },
            duolingo: {
                theory: `
                    <h4>Duolingo English Test Preparation</h4>

                    <h5>1. Test Format</h5>
                    <ul>
                        <li><strong>Adaptive Testing</strong>
                            <ul>
                                <li>Question difficulty adjusts</li>
                                <li>Unique test experience</li>
                                <li>Efficient assessment</li>
                            </ul>
                        </li>
                        <li><strong>Skills Tested</strong>
                            <ul>
                                <li>Reading comprehension</li>
                                <li>Listening comprehension</li>
                                <li>Writing ability</li>
                                <li>Speaking ability</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>2. Question Types</h5>
                    <ul>
                        <li><strong>Reading</strong>
                            <ul>
                                <li>Read and complete</li>
                                <li>Read and select</li>
                                <li>Read aloud</li>
                            </ul>
                        </li>
                        <li><strong>Writing</strong>
                            <ul>
                                <li>Write about the image</li>
                                <li>Write your response</li>
                                <li>Complete the story</li>
                            </ul>
                        </li>
                    </ul>
                `,
                examples: `
                    <h4>Duolingo Test Examples</h4>

                    <h5>1. Sample Questions</h5>
                    <div class="example-box">
                        <p><strong>Reading Example:</strong></p>
                        <p>Complete the sentence:</p>
                        <p>"The museum is ____ on Mondays."</p>
                        <ul>
                            <li>closed</li>
                            <li>closing</li>
                            <li>closes</li>
                            <li>close</li>
                        </ul>
                    </div>

                    <h5>2. Writing Example</h5>
                    <div class="example-box">
                        <p><strong>Image Description Task:</strong></p>
                        <img src="sample_image.jpg" alt="City scene">
                        <p>Write 50-75 words describing this image.</p>
                    </div>
                `,
                practice: `
                    <h4>Duolingo Practice Exercises</h4>

                    <h5>1. Vocabulary Practice</h5>
                    <div class="practice-exercise">
                        <p><strong>Complete these sentences:</strong></p>
                        <ol>
                            <li>The weather is ____ today.</li>
                            <li>She ____ to work every day.</li>
                            <li>They ____ studying English.</li>
                        </ol>
                    </div>

                    <h5>2. Speaking Practice</h5>
                    <div class="practice-exercise">
                        <p><strong>Record yourself:</strong></p>
                        <p>Describe your daily routine in 30 seconds</p>
                        <button class="record-button">Start Recording</button>
                    </div>
                `
            }
        };

        this.initializeEventListeners();
        this.initializeTabs();
    }

    initializeEventListeners() {
        document.querySelectorAll('.start-quiz-btn').forEach(btn => {
            btn.addEventListener('click', () => this.startQuiz(btn.dataset.module));
        });

        document.getElementById('prevBtn').addEventListener('click', () => this.navigateQuestion(-1));
        document.getElementById('nextBtn').addEventListener('click', () => this.navigateQuestion(1));
        document.getElementById('askAIBtn').addEventListener('click', () => this.askAI());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetQuiz());
        document.getElementById('viewResultsBtn').addEventListener('click', () => this.showResults());
    }

    initializeTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });
    }

    switchTab(tabId) {
        // Update active button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });

        // Show selected content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = content.id === tabId ? 'block' : 'none';
        });

        // Load content if not already loaded
        this.loadTabContent(tabId);
    }

    loadTabContent(tabId) {
        if (!this.currentModule) return;
        
        const contentDiv = document.querySelector(`#${tabId} > div`);
        contentDiv.innerHTML = this.learningContent[this.currentModule][tabId];
    }

    startQuiz(module) {
        this.currentModule = module;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        document.querySelector('.language-modules').style.display = 'none';
        document.querySelector('.quiz-section').style.display = 'block';

        document.getElementById('quizTitle').textContent = 
            `${module.charAt(0).toUpperCase() + module.slice(1)} Quiz`;

        this.loadQuestion();
        this.loadTabContent('theory');
        document.querySelector('.learning-content').style.display = 'block';
    }

    loadQuestion() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        document.getElementById('questionText').textContent = question.question;

        const optionsContainer = document.querySelector('.options-container');
        optionsContainer.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.textContent = option;
            
            if (this.userAnswers.has(this.currentQuestionIndex)) {
                optionElement.classList.add('disabled');
                const userAnswer = this.userAnswers.get(this.currentQuestionIndex);
                const correctAnswer = question.correct;
                
                if (index === correctAnswer) {
                    optionElement.classList.add('correct');
                } else if (index === userAnswer && userAnswer !== correctAnswer) {
                    optionElement.classList.add('incorrect');
                }
            }

            optionElement.addEventListener('click', () => this.selectOption(index));
            optionsContainer.appendChild(optionElement);
        });

        this.updateProgress();

        // Hide feedback when loading new question
        document.querySelector('.result-feedback').style.display = 'none';
    }

    selectOption(index) {
        // If already answered, don't allow new selection
        if (this.userAnswers.has(this.currentQuestionIndex)) {
            return;
        }

        this.userAnswers.set(this.currentQuestionIndex, index);
        
        // Get the correct answer
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const correctIndex = question.correct;

        // Update options appearance
        document.querySelectorAll('.option').forEach((option, i) => {
            option.classList.add('disabled');
            if (i === correctIndex) {
                option.classList.add('correct');
            } else if (i === index && index !== correctIndex) {
                option.classList.add('incorrect');
            }
        });

        // Show immediate feedback
        this.showFeedback(index);
        
        // Show view results button if at least one question is answered
        this.hasAnswered = true;
        document.getElementById('viewResultsBtn').style.display = 'flex';
    }

    navigateQuestion(direction) {
        const newIndex = this.currentQuestionIndex + direction;
        if (newIndex >= 0 && newIndex < this.questions[this.currentModule].length) {
            this.currentQuestionIndex = newIndex;
            this.loadQuestion();
        }
    }

    updateProgress() {
        const total = this.questions[this.currentModule].length;
        document.getElementById('questionCounter').textContent = 
            `Question ${this.currentQuestionIndex + 1}/${total}`;

        const progress = ((this.currentQuestionIndex + 1) / total) * 100;
        document.querySelector('.progress').style.width = `${progress}%`;
    }

    askAI() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const chatInput = document.querySelector('#userInput');
        const sendButton = document.querySelector('#sendBtn');
        const chatToggle = document.querySelector('#chatToggle');

        if (chatInput && sendButton && chatToggle) {
            const prompt = `Please explain this question and its answer:
                Question: ${question.question}
                Correct Answer: ${question.options[question.correct]}
                Explanation: ${question.explanation}`;

            chatInput.value = prompt;
            
            chatInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            // Open chat if not already open
            if (!document.querySelector('.chat-widget.active')) {
                chatToggle.click();
            }

            // Trigger send
            sendButton.click();
        }
    }

    resetQuiz() {
        // Reset all state
        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        // Show tutorials, hide quiz
        document.querySelector('.language-modules').style.display = 'grid';
        document.querySelector('.quiz-section').style.display = 'none';

        // Reset progress bar
        document.querySelector('.progress').style.width = '0%';

        // Optional: Scroll to top of tutorials
        document.querySelector('.tutorial-header').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }

    showFeedback(selectedIndex) {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const feedbackDiv = document.querySelector('.result-feedback');
        const feedbackText = feedbackDiv.querySelector('.feedback-text');
        const explanationText = feedbackDiv.querySelector('.explanation-text');
        
        const isCorrect = selectedIndex === question.correct;
        
        feedbackDiv.style.display = 'block';
        feedbackDiv.className = `result-feedback ${isCorrect ? 'correct' : 'incorrect'}`;
        
        feedbackText.textContent = isCorrect ? 
            'Correct Answer!' : 
            `Incorrect. The correct answer is: ${question.options[question.correct]}`;
        
        explanationText.textContent = question.explanation;
    }

    showResults() {
        const total = this.questions[this.currentModule].length;
        let correct = 0;
        
        this.userAnswers.forEach((answer, questionIndex) => {
            if (answer === this.questions[this.currentModule][questionIndex].correct) {
                correct++;
            }
        });

        const percentage = (correct / total) * 100;
        
        // Create results modal
        const modal = document.createElement('div');
        modal.className = 'results-modal';
        modal.innerHTML = `
            <div class="results-content">
                <h3>Quiz Results</h3>
                <div class="score-circle">
                    <span class="score-percentage">${percentage.toFixed(1)}%</span>
                    <span class="score-text">${correct} out of ${total}</span>
                </div>
                <button class="close-results">Close</button>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Add close functionality
        modal.querySelector('.close-results').addEventListener('click', () => {
            modal.remove();
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LanguageSkillsQuiz();
});