// language-skills.js
class LanguageSkillsQuiz {
    constructor() {
        this.questions = {
            quantitative: [
                {
                    question: "If a train travels 360 kilometers in 4 hours, what is its average speed?",
                    options: ["80 km/h", "90 km/h", "85 km/h", "95 km/h"],
                    correct: 1,
                    explanation: "Average speed = Total distance / Total time = 360/4 = 90 kilometers per hour"
                },
                {
                    question: "What is 15% of 200?",
                    options: ["25", "30", "35", "40"],
                    correct: 1,
                    explanation: "15% of 200 = (15/100) × 200 = 30"
                },
                {
                    question: "If x + 3 = 8, what is the value of x?",
                    options: ["4", "5", "6", "11"],
                    correct: 1,
                    explanation: "Subtract 3 from both sides: x = 8 - 3 = 5"
                },
                {
                    question: "A shopkeeper sells an item at 20% profit. If the cost price is ₹100, what is the selling price?",
                    options: ["₹110", "₹120", "₹130", "₹140"],
                    correct: 1,
                    explanation: "Selling price = Cost price + (20% of cost price) = 100 + (20/100 × 100) = 120"
                },
                {
                    question: "What is the square root of 144?",
                    options: ["10", "12", "14", "16"],
                    correct: 1,
                    explanation: "12 × 12 = 144, therefore square root of 144 is 12"
                },
                {
                    question: "If 5x = 25, what is the value of x?",
                    options: ["3", "4", "5", "6"],
                    correct: 2,
                    explanation: "Divide both sides by 5: x = 25/5 = 5"
                },
                {
                    question: "What is the area of a rectangle with length 8m and width 5m?",
                    options: ["35 sq m", "40 sq m", "45 sq m", "50 sq m"],
                    correct: 1,
                    explanation: "Area of rectangle = length × width = 8 × 5 = 40 square meters"
                },
                {
                    question: "If a:b = 2:3 and b:c = 4:5, what is a:c?",
                    options: ["8:15", "6:15", "10:15", "12:15"],
                    correct: 0,
                    explanation: "First convert to same ratio: a:b = 8:12, b:c = 12:15, therefore a:c = 8:15"
                },
                {
                    question: "What is the simple interest on ₹1000 at 10% per annum for 2 years?",
                    options: ["₹100", "₹200", "₹300", "₹400"],
                    correct: 1,
                    explanation: "Simple Interest = (Principal × Rate × Time)/100 = (1000 × 10 × 2)/100 = 200"
                },
                {
                    question: "If 6 workers can complete a job in 12 days, how many days will 9 workers take?",
                    options: ["6", "8", "10", "14"],
                    correct: 1,
                    explanation: "Using inverse proportion: (6 × 12)/9 = 8 days"
                }
            ],
            logical: [
                {
                    question: "If all roses are flowers and all flowers fade, which conclusion is valid?",
                    options: [
                        "Some flowers are roses",
                        "All roses fade",
                        "Some roses don't fade",
                        "No roses fade"
                    ],
                    correct: 1,
                    explanation: "Using syllogism: If all roses are flowers and all flowers fade, then all roses must fade"
                },
                {
                    question: "In a row of students, Rahul is 8th from the left and 12th from the right. How many students are in the row?",
                    options: ["19", "20", "18", "21"],
                    correct: 0,
                    explanation: "Total students = Left position + Right position - 1 = 8 + 12 - 1 = 19"
                },
                {
                    question: "If FRIEND is coded as HUMJTK, how is CANDLE coded?",
                    options: ["EDRJQN", "DCQIKG", "ESJHQK", "ECPFNG"],
                    correct: 2,
                    explanation: "Each letter is moved 2 positions forward in the alphabet"
                },
                {
                    question: "Complete the series: 2, 6, 12, 20, ?",
                    options: ["30", "28", "32", "26"],
                    correct: 0,
                    explanation: "Pattern is adding consecutive even numbers: +4, +6, +8, +10"
                },
                {
                    question: "If South-East becomes North, North-East becomes West, what will South become?",
                    options: ["North-West", "South-West", "North-East", "East"],
                    correct: 2,
                    explanation: "The direction is rotated 90° clockwise"
                },
                {
                    question: "Find the odd one out: Cup, Plate, Spoon, Table, Bowl",
                    options: ["Cup", "Plate", "Table", "Bowl"],
                    correct: 2,
                    explanation: "Table is furniture while others are utensils/crockery"
                },
                {
                    question: "If A + B means A is the mother of B; A × B means A is the sister of B; A ÷ B means A is the father of B; A - B means A is the brother of B, then which of the following means C is the aunt of P?",
                    options: [
                        "C × N + P",
                        "C - N + P",
                        "C + N × P",
                        "C ÷ N + P"
                    ],
                    correct: 0,
                    explanation: "C × N + P means C is sister of N and N is mother of P, making C the aunt of P"
                },
                {
                    question: "In a certain code, '256' means 'red sweet apple', '589' means 'sweet juicy orange' and '234' means 'apple and orange'. Which digit stands for 'red'?",
                    options: ["2", "5", "6", "8"],
                    correct: 0,
                    explanation: "By comparing codes, 2 must represent 'red' as it's unique to 'red sweet apple'"
                },
                {
                    question: "If 'MOUSE' is written as 'PRUQC', how is 'SHIFT' written in that code?",
                    options: ["UJKHV", "VJKHU", "QFGDR", "UJGKV"],
                    correct: 1,
                    explanation: "Each letter is moved 3 positions forward in the alphabet"
                },
                {
                    question: "A square is divided into 9 equal parts. How many rectangles can be formed?",
                    options: ["18", "20", "22", "24"],
                    correct: 2,
                    explanation: "By combining different parts, 22 different rectangles can be formed"
                }
            ]
        };

        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers = new Map();
        this.hasAnswered = false;

        this.learningContent = {
            quantitative: {
                theory: `
                    <h4>Quantitative Aptitude Fundamentals</h4>
                    
                    <h5>1. Number System</h5>
                    <ul>
                        <li><strong>Natural Numbers:</strong> 1, 2, 3, ...</li>
                        <li><strong>Whole Numbers:</strong> 0, 1, 2, 3, ...</li>
                        <li><strong>Integers:</strong> ...-3, -2, -1, 0, 1, 2, 3...</li>
                        <li><strong>Rational Numbers:</strong> Numbers expressed as p/q</li>
                        <li><strong>Irrational Numbers:</strong> Numbers with non-terminating decimals</li>
                    </ul>

                    <h5>2. Basic Operations</h5>
                    <ul>
                        <li><strong>BODMAS Rule:</strong> 
                            <ul>
                                <li>Brackets</li>
                                <li>Orders (powers/roots)</li>
                                <li>Division and Multiplication</li>
                                <li>Addition and Subtraction</li>
                            </ul>
                        </li>
                    </ul>

                    <h5>3. Percentages</h5>
                    <ul>
                        <li>Converting fractions to percentages</li>
                        <li>Percentage increase/decrease</li>
                        <li>Profit and loss calculations</li>
                        <li>Simple and compound interest</li>
                    </ul>

                    <h5>4. Ratios and Proportions</h5>
                    <ul>
                        <li>Direct proportion</li>
                        <li>Inverse proportion</li>
                        <li>Compound proportion</li>
                    </ul>

                    <h5>5. Time and Work</h5>
                    <ul>
                        <li>Time, speed, and distance</li>
                        <li>Work and time problems</li>
                        <li>Pipes and cisterns</li>
                    </ul>
                `,
                examples: `
                    <h4>Quantitative Examples</h4>
                    
                    <div class="example-item">
                        <h5>Percentage Problems</h5>
                        <p><strong>Example 1:</strong> Find 15% of 200</p>
                        <p>Solution: (15/100) × 200 = 30</p>

                        <h5>Profit and Loss</h5>
                        <p><strong>Example 2:</strong> Cost Price = ₹100, Profit = 20%</p>
                        <p>Solution: Selling Price = 100 + (20% of 100) = ₹120</p>

                        <h5>Time and Distance</h5>
                        <p><strong>Example 3:</strong> Speed = 60 km/h, Time = 2 hours</p>
                        <p>Solution: Distance = Speed × Time = 120 km</p>
                    </div>
                `,
                practice: `
                    <h4>Practice Problems</h4>
                    
                    <div class="practice-item">
                        <h5>Exercise 1: Percentages</h5>
                        <p>Calculate:</p>
                        <ol>
                            <li>25% of 80</li>
                            <li>40% of 150</li>
                            <li>75% of 200</li>
                        </ol>

                        <h5>Exercise 2: Profit/Loss</h5>
                        <p>Find the selling price if:</p>
                        <ul>
                            <li>Cost Price = ₹500, Profit = 30%</li>
                            <li>Cost Price = ₹1000, Loss = 20%</li>
                        </ul>
                    </div>
                `
            },
            logical: {
                theory: `
                    <h4>Logical Reasoning Fundamentals</h4>
                    
                    <h5>1. Verbal Reasoning</h5>
                    <ul>
                        <li><strong>Analogies:</strong> Word relationships</li>
                        <li><strong>Series Completion:</strong> Pattern recognition</li>
                        <li><strong>Classification:</strong> Grouping similar items</li>
                        <li><strong>Coding-Decoding:</strong> Letter/number patterns</li>
                    </ul>

                    <h5>2. Non-verbal Reasoning</h5>
                    <ul>
                        <li><strong>Pattern Series:</strong> Visual patterns</li>
                        <li><strong>Figure Analogies:</strong> Shape relationships</li>
                        <li><strong>Classification:</strong> Grouping similar figures</li>
                        <li><strong>Embedded Figures:</strong> Hidden shapes</li>
                    </ul>

                    <h5>3. Logical Deduction</h5>
                    <ul>
                        <li>Syllogisms</li>
                        <li>Statement-Conclusion</li>
                        <li>Logical Sequence</li>
                        <li>Blood Relations</li>
                    </ul>

                    <h5>4. Data Interpretation</h5>
                    <ul>
                        <li>Tables and Graphs</li>
                        <li>Pie Charts</li>
                        <li>Bar Diagrams</li>
                        <li>Line Graphs</li>
                    </ul>
                `,
                examples: `
                    <h4>Logical Reasoning Examples</h4>
                    
                    <div class="example-item">
                        <h5>Syllogism Example</h5>
                        <p><strong>Premise 1:</strong> All cats are animals</p>
                        <p><strong>Premise 2:</strong> All animals need food</p>
                        <p><strong>Conclusion:</strong> Therefore, all cats need food</p>

                        <h5>Coding Example</h5>
                        <p><strong>If PAPER = SCTGW, then:</strong></p>
                        <p>Each letter is moved 3 positions forward</p>
                        <p>Therefore, BOOK = ERRN</p>
                    </div>
                `,
                practice: `
                    <h4>Practice Exercises</h4>
                    
                    <div class="practice-item">
                        <h5>Exercise 1: Series Completion</h5>
                        <p>Complete the series:</p>
                        <ol>
                            <li>2, 5, 9, 14, ___</li>
                            <li>B, D, G, K, ___</li>
                        </ol>

                        <h5>Exercise 2: Analogies</h5>
                        <p>Complete the analogies:</p>
                        <ul>
                            <li>Book : Pages :: Tree : ?</li>
                            <li>Clock : Time :: Thermometer : ?</li>
                        </ul>
                    </div>
                `
            }
        };

        this.initializeEventListeners();
        this.initializeTabs();
    }

    initializeEventListeners() {
        document.querySelectorAll('.start-quiz-btn').forEach(btn => {
            btn.addEventListener('click', () => this.startQuiz(btn.dataset.module));
        });

        document.getElementById('prevBtn').addEventListener('click', () => this.navigateQuestion(-1));
        document.getElementById('nextBtn').addEventListener('click', () => this.navigateQuestion(1));
        document.getElementById('askAIBtn').addEventListener('click', () => this.askAI());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetQuiz());
        document.getElementById('viewResultsBtn').addEventListener('click', () => this.showResults());
    }

    initializeTabs() {
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => this.switchTab(btn.dataset.tab));
        });
    }

    switchTab(tabId) {
        // Update active button
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabId);
        });

        // Show selected content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = content.id === tabId ? 'block' : 'none';
        });

        // Load content if not already loaded
        this.loadTabContent(tabId);
    }

    loadTabContent(tabId) {
        if (!this.currentModule) return;
        
        const contentDiv = document.querySelector(`#${tabId} > div`);
        contentDiv.innerHTML = this.learningContent[this.currentModule][tabId];
    }

    startQuiz(module) {
        this.currentModule = module;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        document.querySelector('.language-modules').style.display = 'none';
        document.querySelector('.quiz-section').style.display = 'block';

        document.getElementById('quizTitle').textContent = 
            `${module.charAt(0).toUpperCase() + module.slice(1)} Quiz`;

        this.loadQuestion();
        this.loadTabContent('theory');
        document.querySelector('.learning-content').style.display = 'block';
    }

    loadQuestion() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        document.getElementById('questionText').textContent = question.question;

        const optionsContainer = document.querySelector('.options-container');
        optionsContainer.innerHTML = '';

        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'option';
            optionElement.textContent = option;
            
            if (this.userAnswers.has(this.currentQuestionIndex)) {
                optionElement.classList.add('disabled');
                const userAnswer = this.userAnswers.get(this.currentQuestionIndex);
                const correctAnswer = question.correct;
                
                if (index === correctAnswer) {
                    optionElement.classList.add('correct');
                } else if (index === userAnswer && userAnswer !== correctAnswer) {
                    optionElement.classList.add('incorrect');
                }
            }

            optionElement.addEventListener('click', () => this.selectOption(index));
            optionsContainer.appendChild(optionElement);
        });

        this.updateProgress();

        // Hide feedback when loading new question
        document.querySelector('.result-feedback').style.display = 'none';
    }

    selectOption(index) {
        // If already answered, don't allow new selection
        if (this.userAnswers.has(this.currentQuestionIndex)) {
            return;
        }

        this.userAnswers.set(this.currentQuestionIndex, index);
        
        // Get the correct answer
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const correctIndex = question.correct;

        // Update options appearance
        document.querySelectorAll('.option').forEach((option, i) => {
            option.classList.add('disabled');
            if (i === correctIndex) {
                option.classList.add('correct');
            } else if (i === index && index !== correctIndex) {
                option.classList.add('incorrect');
            }
        });

        // Show immediate feedback
        this.showFeedback(index);
        
        // Show view results button if at least one question is answered
        this.hasAnswered = true;
        document.getElementById('viewResultsBtn').style.display = 'flex';
    }

    navigateQuestion(direction) {
        const newIndex = this.currentQuestionIndex + direction;
        if (newIndex >= 0 && newIndex < this.questions[this.currentModule].length) {
            this.currentQuestionIndex = newIndex;
            this.loadQuestion();
        }
    }

    updateProgress() {
        const total = this.questions[this.currentModule].length;
        document.getElementById('questionCounter').textContent = 
            `Question ${this.currentQuestionIndex + 1}/${total}`;

        const progress = ((this.currentQuestionIndex + 1) / total) * 100;
        document.querySelector('.progress').style.width = `${progress}%`;
    }

    askAI() {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const chatInput = document.querySelector('#userInput');
        const sendButton = document.querySelector('#sendBtn');
        const chatToggle = document.querySelector('#chatToggle');

        if (chatInput && sendButton && chatToggle) {
            const prompt = `Please explain this question and its answer:
                Question: ${question.question}
                Correct Answer: ${question.options[question.correct]}
                Explanation: ${question.explanation}`;

            chatInput.value = prompt;
            
            chatInput.dispatchEvent(new Event('input', { bubbles: true }));
            
            // Open chat if not already open
            if (!document.querySelector('.chat-widget.active')) {
                chatToggle.click();
            }

            // Trigger send
            sendButton.click();
        }
    }

    resetQuiz() {
        // Reset all state
        this.currentModule = null;
        this.currentQuestionIndex = 0;
        this.userAnswers.clear();

        // Show tutorials, hide quiz
        document.querySelector('.language-modules').style.display = 'grid';
        document.querySelector('.quiz-section').style.display = 'none';

        // Reset progress bar
        document.querySelector('.progress').style.width = '0%';

        // Optional: Scroll to top of tutorials
        document.querySelector('.tutorial-header').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }

    showFeedback(selectedIndex) {
        const question = this.questions[this.currentModule][this.currentQuestionIndex];
        const feedbackDiv = document.querySelector('.result-feedback');
        const feedbackText = feedbackDiv.querySelector('.feedback-text');
        const explanationText = feedbackDiv.querySelector('.explanation-text');
        
        const isCorrect = selectedIndex === question.correct;
        
        feedbackDiv.style.display = 'block';
        feedbackDiv.className = `result-feedback ${isCorrect ? 'correct' : 'incorrect'}`;
        
        feedbackText.textContent = isCorrect ? 
            'Correct Answer!' : 
            `Incorrect. The correct answer is: ${question.options[question.correct]}`;
        
        explanationText.textContent = question.explanation;
    }

    showResults() {
        const total = this.questions[this.currentModule].length;
        let correct = 0;
        
        this.userAnswers.forEach((answer, questionIndex) => {
            if (answer === this.questions[this.currentModule][questionIndex].correct) {
                correct++;
            }
        });

        const percentage = (correct / total) * 100;
        
        // Create results modal
        const modal = document.createElement('div');
        modal.className = 'results-modal';
        modal.innerHTML = `
            <div class="results-content">
                <h3>Quiz Results</h3>
                <div class="score-circle">
                    <span class="score-percentage">${percentage.toFixed(1)}%</span>
                    <span class="score-text">${correct} out of ${total}</span>
                </div>
                <button class="close-results">Close</button>
            </div>
        `;

        document.body.appendChild(modal);
        
        // Add close functionality
        modal.querySelector('.close-results').addEventListener('click', () => {
            modal.remove();
        });
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new LanguageSkillsQuiz();
});