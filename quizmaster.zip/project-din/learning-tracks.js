document.addEventListener('DOMContentLoaded', () => {
    // Track data for all categories
    const trackData = {
        ml: {
            title: "Machine Learning Learning Tracks",
            description: "Master machine learning concepts from basics to advanced applications",
            tracks: {
                beginner: {
                    icon: "fas fa-seedling",
                    title: "Beginner Track", 
                    description: "Start your machine learning journey with fundamental concepts and basic algorithms.",
                    features: ["Python Basics for ML", "Data Preprocessing", "Basic Statistics", "Intro to Scikit-learn"],
                    modules: [
                        {
                            number: 1,
                            title: "Introduction to ML",
                            description: "Basic concepts and terminology",
                            duration: "2h 30m"
                        },
                        {
                            number: 2,
                            title: "Python for Data Analysis",
                            description: "NumPy, Pandas, and data manipulation",
                            duration: "3h 15m"
                        },
                        {
                            number: 3,
                            title: "Data Preprocessing",
                            description: "Cleaning and preparing datasets",
                            duration: "2h 45m"
                        },
                        {
                            number: 4,
                            title: "Basic ML Algorithms",
                            description: "Linear regression and classification",
                            duration: "4h 00m"
                        }
                    ],
                    totalHours: "12.5",
                    moduleCount: 4
                },
                intermediate: {
                    icon: "fas fa-tree",
                    title: "Intermediate Track",
                    description: "Deepen your ML knowledge with advanced algorithms and real-world applications.",
                    features: ["Advanced ML Algorithms", "Neural Networks", "Model Evaluation", "Feature Engineering"],
                    modules: [
                        {
                            number: 1,
                            title: "Advanced Algorithms",
                            description: "SVM, Random Forests, and Ensemble Methods",
                            duration: "4h 30m"
                        },
                        {
                            number: 2,
                            title: "Neural Networks",
                            description: "Deep learning fundamentals",
                            duration: "5h 00m"
                        },
                        {
                            number: 3,
                            title: "Model Evaluation",
                            description: "Metrics, validation and tuning",
                            duration: "3h 30m"
                        },
                        {
                            number: 4,
                            title: "Feature Engineering",
                            description: "Advanced data preprocessing",
                            duration: "4h 00m"
                        }
                    ],
                    totalHours: "17",
                    moduleCount: 4
                },
                advanced: {
                    icon: "fas fa-brain",
                    title: "Advanced Track",
                    description: "Master complex ML concepts and cutting-edge techniques.",
                    features: ["Deep Learning", "Natural Language Processing", "Computer Vision", "Reinforcement Learning"],
                    modules: [
                        {
                            number: 1,
                            title: "Deep Learning Fundamentals",
                            description: "Neural Networks and Deep Architectures",
                            duration: "5h 00m"
                        },
                        {
                            number: 2,
                            title: "Natural Language Processing",
                            description: "Text processing and language models",
                            duration: "6h 00m"
                        },
                        {
                            number: 3,
                            title: "Computer Vision",
                            description: "Image processing and CNNs",
                            duration: "5h 30m"
                        },
                        {
                            number: 4,
                            title: "Reinforcement Learning",
                            description: "RL algorithms and applications",
                            duration: "5h 30m"
                        }
                    ],
                    totalHours: "22",
                    moduleCount: 4
                }
            }
        },
        web: {
            title: "Web Development Learning Tracks",
            description: "Master modern web development from frontend to backend",
            tracks: {
                beginner: {
                    icon: "fas fa-code",
                    title: "Frontend Fundamentals",
                    description: "Learn the basics of web development with HTML, CSS, and JavaScript.",
                    features: ["HTML5 & CSS3", "JavaScript Basics", "Responsive Design", "Basic UI/UX"],
                    modules: [
                        {
                            number: 1,
                            title: "HTML Foundations",
                            description: "Structure and semantics",
                            duration: "2h 00m"
                        },
                        {
                            number: 2,
                            title: "CSS Styling",
                            description: "Layout and design",
                            duration: "3h 00m"
                        },
                        {
                            number: 3,
                            title: "JavaScript Basics",
                            description: "Programming fundamentals",
                            duration: "3h 30m"
                        },
                        {
                            number: 4,
                            title: "Responsive Design",
                            description: "Mobile-first approach",
                            duration: "2h 00m"
                        }
                    ],
                    totalHours: "10.5",
                    moduleCount: 4
                },
                intermediate: {
                    icon: "fas fa-laptop-code",
                    title: "Frontend Frameworks",
                    description: "Master modern frontend frameworks and tools.",
                    features: ["React", "State Management", "API Integration", "Testing"],
                    modules: [
                        {
                            number: 1,
                            title: "React Fundamentals",
                            description: "Components and props",
                            duration: "4h 00m"
                        },
                        {
                            number: 2,
                            title: "State Management",
                            description: "Redux and Context API",
                            duration: "3h 30m"
                        },
                        {
                            number: 3,
                            title: "API Integration",
                            description: "REST and GraphQL",
                            duration: "3h 00m"
                        },
                        {
                            number: 4,
                            title: "Testing",
                            description: "Unit and integration tests",
                            duration: "3h 30m"
                        }
                    ],
                    totalHours: "14",
                    moduleCount: 4
                },
                advanced: {
                    icon: "fas fa-server",
                    title: "Full Stack Development",
                    description: "Build complete web applications with frontend and backend.",
                    features: ["Node.js", "Databases", "Authentication", "Deployment"],
                    modules: [
                        {
                            number: 1,
                            title: "Backend Development",
                            description: "Node.js and Express",
                            duration: "5h 00m"
                        },
                        {
                            number: 2,
                            title: "Database Design",
                            description: "SQL and NoSQL",
                            duration: "4h 30m"
                        },
                        {
                            number: 3,
                            title: "Authentication",
                            description: "JWT and OAuth",
                            duration: "3h 30m"
                        },
                        {
                            number: 4,
                            title: "Deployment",
                            description: "Cloud platforms and DevOps",
                            duration: "4h 00m"
                        }
                    ],
                    totalHours: "17",
                    moduleCount: 4
                }
            }
        },
        data: {
            title: "Data Science Learning Tracks",
            description: "Master data science from statistics to advanced analytics",
            tracks: {
                beginner: {
                    icon: "fas fa-chart-bar",
                    title: "Data Analysis Fundamentals",
                    description: "Learn the basics of data analysis and visualization.",
                    features: ["Statistics", "Data Visualization", "Excel", "SQL Basics"],
                    modules: [
                        {
                            number: 1,
                            title: "Statistics Fundamentals",
                            description: "Basic statistical concepts",
                            duration: "3h 00m"
                        },
                        {
                            number: 2,
                            title: "Data Visualization",
                            description: "Charts and graphs",
                            duration: "2h 30m"
                        },
                        {
                            number: 3,
                            title: "Excel Analytics",
                            description: "Spreadsheet analysis",
                            duration: "2h 30m"
                        },
                        {
                            number: 4,
                            title: "SQL Queries",
                            description: "Database basics",
                            duration: "3h 00m"
                        }
                    ],
                    totalHours: "11",
                    moduleCount: 4
                },
                intermediate: {
                    icon: "fas fa-database",
                    title: "Data Engineering",
                    description: "Learn data processing and engineering techniques.",
                    features: ["ETL", "Big Data", "Data Warehousing", "Python"],
                    modules: [
                        {
                            number: 1,
                            title: "ETL Processes",
                            description: "Data pipeline development",
                            duration: "4h 00m"
                        },
                        {
                            number: 2,
                            title: "Big Data Processing",
                            description: "Hadoop and Spark",
                            duration: "5h 00m"
                        },
                        {
                            number: 3,
                            title: "Data Warehousing",
                            description: "Design and implementation",
                            duration: "4h 00m"
                        },
                        {
                            number: 4,
                            title: "Python for Data",
                            description: "Data processing with Python",
                            duration: "4h 00m"
                        }
                    ],
                    totalHours: "17",
                    moduleCount: 4
                },
                advanced: {
                    icon: "fas fa-microscope",
                    title: "Advanced Analytics",
                    description: "Master advanced data science techniques.",
                    features: ["Advanced Statistics", "Predictive Modeling", "Time Series", "Deep Learning"],
                    modules: [
                        {
                            number: 1,
                            title: "Advanced Statistics",
                            description: "Statistical modeling",
                            duration: "5h 00m"
                        },
                        {
                            number: 2,
                            title: "Predictive Analytics",
                            description: "Forecasting methods",
                            duration: "5h 00m"
                        },
                        {
                            number: 3,
                            title: "Time Series Analysis",
                            description: "Temporal data analysis",
                            duration: "4h 30m"
                        },
                        {
                            number: 4,
                            title: "Deep Learning",
                            description: "Neural networks for data",
                            duration: "5h 30m"
                        }
                    ],
                    totalHours: "20",
                    moduleCount: 4
                }
            }
        },
        cloud: {
            title: "Cloud Computing Learning Tracks",
            description: "Master cloud platforms and services",
            tracks: {
                beginner: {
                    icon: "fas fa-cloud",
                    title: "Cloud Basics",
                    description: "Introduction to cloud computing concepts.",
                    features: ["Cloud Fundamentals", "AWS Basics", "Security", "Networking"],
                    modules: [
                        {
                            number: 1,
                            title: "Cloud Computing Basics",
                            description: "Core concepts",
                            duration: "2h 30m"
                        },
                        {
                            number: 2,
                            title: "AWS Introduction",
                            description: "Basic AWS services",
                            duration: "3h 00m"
                        },
                        {
                            number: 3,
                            title: "Cloud Security",
                            description: "Basic security concepts",
                            duration: "2h 30m"
                        },
                        {
                            number: 4,
                            title: "Networking",
                            description: "Cloud networking basics",
                            duration: "3h 00m"
                        }
                    ],
                    totalHours: "11",
                    moduleCount: 4
                },
                intermediate: {
                    icon: "fas fa-server",
                    title: "Cloud Architecture",
                    description: "Design and implement cloud solutions.",
                    features: ["Solution Architecture", "DevOps", "Containers", "Serverless"],
                    modules: [
                        {
                            number: 1,
                            title: "Solution Design",
                            description: "Architecture patterns",
                            duration: "4h 00m"
                        },
                        {
                            number: 2,
                            title: "DevOps Practices",
                            description: "CI/CD pipelines",
                            duration: "4h 30m"
                        },
                        {
                            number: 3,
                            title: "Container Services",
                            description: "Docker and Kubernetes",
                            duration: "5h 00m"
                        },
                        {
                            number: 4,
                            title: "Serverless Computing",
                            description: "Lambda and Functions",
                            duration: "4h 30m"
                        }
                    ],
                    totalHours: "18",
                    moduleCount: 4
                },
                advanced: {
                    icon: "fas fa-network-wired",
                    title: "Enterprise Cloud",
                    description: "Advanced cloud solutions and management.",
                    features: ["Multi-Cloud", "Migration", "Cost Optimization", "Security"],
                    modules: [
                        {
                            number: 1,
                            title: "Multi-Cloud Strategy",
                            description: "Cross-platform solutions",
                            duration: "5h 00m"
                        },
                        {
                            number: 2,
                            title: "Cloud Migration",
                            description: "Migration strategies",
                            duration: "5h 30m"
                        },
                        {
                            number: 3,
                            title: "Cost Management",
                            description: "Optimization techniques",
                            duration: "4h 00m"
                        },
                        {
                            number: 4,
                            title: "Advanced Security",
                            description: "Security architecture",
                            duration: "5h 30m"
                        }
                    ],
                    totalHours: "20",
                    moduleCount: 4
                }
            }
        },
        mobile: {
            title: "Mobile Development Learning Tracks",
            description: "Master mobile app development for iOS and Android",
            tracks: {
                beginner: {
                    icon: "fas fa-mobile-alt",
                    title: "Mobile Basics",
                    description: "Learn the fundamentals of mobile development.",
                    features: ["UI Design", "Swift Basics", "Kotlin Basics", "App Lifecycle"],
                    modules: [
                        {
                            number: 1,
                            title: "Mobile UI Design",
                            description: "Design principles",
                            duration: "2h 30m"
                        },
                        {
                            number: 2,
                            title: "Swift Programming",
                            description: "iOS development basics",
                            duration: "3h 00m"
                        },
                        {
                            number: 3,
                            title: "Kotlin Programming",
                            description: "Android development basics",
                            duration: "3h 00m"
                        },
                        {
                            number: 4,
                            title: "App Fundamentals",
                            description: "Basic app structure",
                            duration: "2h 30m"
                        }
                    ],
                    totalHours: "11",
                    moduleCount: 4
                },
                intermediate: {
                    icon: "fas fa-tablet-alt",
                    title: "Platform Development",
                    description: "Build native apps for iOS and Android.",
                    features: ["iOS Development", "Android Development", "Data Storage", "APIs"],
                    modules: [
                        {
                            number: 1,
                            title: "iOS Development",
                            description: "UIKit and SwiftUI",
                            duration: "5h 00m"
                        },
                        {
                            number: 2,
                            title: "Android Development",
                            description: "Android SDK",
                            duration: "5h 00m"
                        },
                        {
                            number: 3,
                            title: "Local Storage",
                            description: "Data persistence",
                            duration: "3h 30m"
                        },
                        {
                            number: 4,
                            title: "API Integration",
                            description: "Network requests",
                            duration: "3h 30m"
                        }
                    ],
                    totalHours: "17",
                    moduleCount: 4
                },
                advanced: {
                    icon: "fas fa-mobile-alt",
                    title: "Cross-Platform Development",
                    description: "Build apps for multiple platforms.",
                    features: ["React Native", "Flutter", "Performance", "Publishing"],
                    modules: [
                        {
                            number: 1,
                            title: "React Native",
                            description: "Cross-platform React",
                            duration: "5h 00m"
                        },
                        {
                            number: 2,
                            title: "Flutter Development",
                            description: "Dart and Flutter",
                            duration: "5h 30m"
                        },
                        {
                            number: 3,
                            title: "App Performance",
                            description: "Optimization techniques",
                            duration: "4h 00m"
                        },
                        {
                            number: 4,
                            title: "App Distribution",
                            description: "Store deployment",
                            duration: "3h 30m"
                        }
                    ],
                    totalHours: "18",
                    moduleCount: 4
                }
            }
        }
    };

    // Function to render track content
    const renderTrackContent = (categoryId) => {
        const category = trackData[categoryId];
        const section = document.getElementById(`${categoryId}Tracks`);
        
        if (!category || !section) return;

        section.innerHTML = `
            <div class="tracks-header">
                <h1>${category.title}</h1>
                <p>${category.description}</p>
            </div>
            <div class="tracks-grid">
                ${Object.entries(category.tracks).map(([level, track]) => `
                    <div class="track-card">
                        <div class="track-header ${level}">
                            <i class="${track.icon}"></i>
                            <h2>${track.title}</h2>
                            <span class="difficulty">${level.charAt(0).toUpperCase() + level.slice(1)} Level</span>
                        </div>
                        <div class="track-content">
                            <div class="track-description">
                                <p>${track.description}</p>
                                <ul class="track-features">
                                    ${track.features.map(feature => `
                                        <li><i class="fas fa-check"></i> ${feature}</li>
                                    `).join('')}
                                </ul>
                            </div>
                            <div class="track-modules">
                                <h3>Learning Modules</h3>
                                <div class="module-list">
                                    ${track.modules.map(module => `
                                        <a href="#" class="module-item" data-module-id="${module.number}">
                                            <span class="module-number">${module.number}</span>
                                            <div class="module-info">
                                                <h4>${module.title}</h4>
                                                <p>${module.description}</p>
                                            </div>
                                            <span class="module-duration">${module.duration}</span>
                                            <i class="fas fa-arrow-right"></i>
                                        </a>
                                    `).join('')}
                                </div>
                            </div>
                            <div class="track-footer">
                                <div class="track-stats">
                                    <div class="stat">
                                        <i class="fas fa-clock"></i>
                                        <span>${track.totalHours} hours</span>
                                    </div>
                                    <div class="stat">
                                        <i class="fas fa-book"></i>
                                        <span>${track.moduleCount} Modules</span>
                                    </div>
                                    <div class="stat">
                                        <i class="fas fa-certificate"></i>
                                        <span>Certificate</span>
                                    </div>
                                </div>
                                <button class="start-track-btn" data-track="${level}">
                                    <i class="fas fa-play"></i>
                                    Start Learning
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;

        // Add event listeners to the newly created elements
        initializeTrackEvents(section);
    };

    // Initialize event listeners for track elements
    const initializeTrackEvents = (section) => {
        // Module click handlers
        section.querySelectorAll('.module-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const moduleId = item.dataset.moduleId;
                // Handle module navigation
                console.log(`Navigate to module ${moduleId}`);
            });
        });

        // Start button handlers
        section.querySelectorAll('.start-track-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const trackLevel = btn.dataset.track;
                // Handle track start
                console.log(`Starting ${trackLevel} track`);
            });
        });
    };

    // Category switching functionality
    const categoryBtns = document.querySelectorAll('.category-btn');
    const tracksSections = document.querySelectorAll('.tracks-section');

    categoryBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const category = btn.dataset.category;
            
            // Update active states
            categoryBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            tracksSections.forEach(section => {
                section.classList.remove('active');
                if (section.id === `${category}Tracks`) {
                    section.classList.add('active');
                    renderTrackContent(category);
                }
            });
        });
    });

    // Initialize the first category
    renderTrackContent('ml');
}); 