// Word Definition Feature
class WordDefinition {
    constructor() {
        this.timeout = null;
        this.container = this.createContainer();
        this.selectedRange = null; // Store the selected range
        this.apiKey = 'YN6ZP5KTV1oHumagAsjFA7xyfBEGaRxkMlbMWg6V';
        this.enabled = true; // Set enabled to true by default
        this.init();
    }

    createContainer() {
        const container = document.createElement('div');
        container.className = 'word-definition-container';
        container.style.display = 'none'; // Initially hide container
        document.body.appendChild(container);
        return container;
    }

    init() {
        document.addEventListener('mouseup', (e) => {
            if (!this.enabled) return; // Check if enabled before processing
            
            const selection = window.getSelection();
            const selectedText = selection.toString().trim();

            // Clear previous timeout and selection
            if (this.timeout) clearTimeout(this.timeout);

            if (selectedText) {
                const range = selection.getRangeAt(0);
                this.selectedRange = range;
                const rect = range.getBoundingClientRect();

                // Check if it's a single word or multiple words
                const isMultipleWords = selectedText.includes(' ');

                // Remove timeout to show immediately
                if (isMultipleWords) {
                    this.showOptions(selectedText, {
                        x: rect.left + window.scrollX,
                        y: rect.bottom + window.scrollY
                    });
                } else {
                    this.showDefinition(selectedText, {
                        x: rect.left + window.scrollX,
                        y: rect.bottom + window.scrollY
                    });
                }
            } else if (!this.container.contains(e.target)) {
                this.hideContainer();
            }
        });

        // Modified click handler
        document.addEventListener('click', (e) => {
            // Don't hide if clicking inside the container
            if (this.container.contains(e.target)) {
                return;
            }

            // Don't hide if clicking on the selected text
            if (this.selectedRange) {
                const rect = this.selectedRange.getBoundingClientRect();
                if (e.clientX >= rect.left && 
                    e.clientX <= rect.right && 
                    e.clientY >= rect.top && 
                    e.clientY <= rect.bottom) {
                    return;
                }
            }

            // Hide in all other cases
            this.hideContainer();
        });

        // Update the close button event listener
        this.container.addEventListener('click', (e) => {
            const closeButton = e.target.closest('.definition-close');
            if (closeButton) {
                this.hideContainer();
            }
        });

        // Close on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.hideContainer();
            }
        });
    }

    hideContainer() {
        this.container.style.display = 'none';
        this.selectedRange = null;
    }

    async showDefinition(word, position) {
        try {
            // Show loading state
            this.container.innerHTML = `
                <div class="word-definition-loading">
                    <div class="loading-spinner"></div>
                    <span>Finding definition...</span>
                </div>
            `;
            this.positionContainer(position);
            this.container.style.display = 'block';

            // Fetch definition
            const response = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
            const data = await response.json();

            if (!response.ok) throw new Error('Word not found');

            // Update to just set the HTML since event handlers are added in formatDefinition
            this.formatDefinition(data[0]);

        } catch (error) {
            this.container.innerHTML = `
                <div class="word-definition-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span>${error.message || 'Failed to get definition'}</span>
                    <button class="btn-primary ask-ai" data-word="${this.escapeText(word)}">
                        <i class="fas fa-robot"></i>
                        Ask AI Instead
                    </button>
                </div>
            `;

            // Add click handler for AI button in error state
            const aiButton = this.container.querySelector('.ask-ai');
            if (aiButton) {
                // Force focus before adding click handler
                setTimeout(() => {
                    aiButton.focus();
                    aiButton.addEventListener('click', (e) => {
                        e.preventDefault();
                        const failedWord = aiButton.dataset.word;
                        if (failedWord) {
                            this.handleAskAI(failedWord);
                        }
                    });
                }, 100);
            }
        }
    }

    showOptions(text, position) {
        const escapedText = this.escapeText(text);
        this.container.innerHTML = `
            <div class="word-definition options-menu">
                <div class="word-header">
                    <div class="word-title-group">
                        <h3>Selected Text</h3>
                        <p class="selected-text">"${text}"</p>
                    </div>
                    <button type="button" class="definition-close" aria-label="Close">×</button>
                </div>
                <div class="options-actions">
                    <button class="btn-primary ask-ai" data-text="${escapedText}">
                        <i class="fas fa-robot"></i>
                        Ask AI about this
                    </button>
                </div>
            </div>
        `;
        this.positionContainer(position);
        this.container.style.display = 'block';

        // Add click handler for AI button
        const aiButton = this.container.querySelector('.ask-ai');
        if (aiButton) {
            // Force focus before adding click handler
            setTimeout(() => {
                aiButton.focus();
                aiButton.addEventListener('click', (e) => {
                    e.preventDefault();
                    const textToAsk = aiButton.dataset.text;
                    this.handleAskAI(textToAsk);
                });
            }, 100);
        }
    }

    handleAskAI(text) {
        try {
            const chatInput = document.querySelector('#userInput');
            const sendButton = document.querySelector('#sendBtn');
            const chatToggle = document.querySelector('#chatToggle');
            
            if (chatInput && sendButton && chatToggle) {
                // Properly format the input text
                const prompt = text.includes(' ') 
                    ? `Explain this text: "${text}"`
                    : `Define this word: "${text}"`;
                
                // Focus the chat input first
                chatInput.focus();
                
                // Set the value and trigger input event
                chatInput.value = prompt;
                chatInput.dispatchEvent(new Event('input', { bubbles: true }));
                
                // Add small delay before clicking buttons
                setTimeout(() => {
                    // Click send button first
                    sendButton.click();
                    
                    // Small delay before toggling chat
                    setTimeout(() => {
                        chatToggle.click();
                    }, 100);
                    
                    // Hide the definition container
                    this.hideContainer();
                }, 100);
            }
        } catch (error) {
            console.error('Error handling AI request:', error);
        }
    }

    formatDefinition(data) {
        const escapedWord = this.escapeText(data.word);
        const html = `
            <div class="word-definition">
                <div class="word-header">
                    <div class="word-title-group">
                        <h3>${data.word}</h3>
                        ${data.phonetic ? `<span class="phonetic">${data.phonetic}</span>` : ''}
                    </div>
                    <button type="button" class="definition-close" aria-label="Close definition">×</button>
                </div>
                ${data.meanings.map(meaning => `
                    <div class="meaning">
                        <span class="part-of-speech">${meaning.partOfSpeech}</span>
                        <ul class="definitions">
                            ${meaning.definitions.slice(0, 3).map(def => `
                                <li>
                                    <p>${def.definition}</p>
                                    ${def.example ? `<span class="example">"${def.example}"</span>` : ''}
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                `).join('')}
                <div class="ai-actions">
                    <button class="btn-primary ask-ai" data-word="${escapedWord}">
                        <i class="fas fa-robot"></i>
                        Ask AI about this word
                    </button>
                </div>
            </div>
        `;

        // Set the HTML
        this.container.innerHTML = html;

        // Add click handler for AI button
        const aiButton = this.container.querySelector('.ask-ai');
        if (aiButton) {
            // Force focus before adding click handler
            setTimeout(() => {
                aiButton.focus();
                aiButton.addEventListener('click', (e) => {
                    e.preventDefault();
                    const word = aiButton.dataset.word;
                    if (word) {
                        this.handleAskAI(word);
                    }
                });
            }, 100);
        }

        return html;
    }

    positionContainer(position) {
        const { x, y } = position;
        const containerRect = this.container.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const scrollY = window.scrollY;
        const scrollX = window.scrollX;
        const padding = 20; // Padding from viewport edges

        // Calculate initial position
        let left = x;
        let top = y + 10;

        // Check right edge
        if (left + containerRect.width > viewportWidth - padding) {
            left = viewportWidth - containerRect.width - padding;
        }

        // Check left edge
        if (left < padding) {
            left = padding;
        }

        // Check bottom edge
        if (top + containerRect.height > viewportHeight + scrollY - padding) {
            // Position above the selection if not enough space below
            top = y - containerRect.height - 10;
            
            // If still no space above, position at the bottom of viewport
            if (top < scrollY + padding) {
                top = viewportHeight + scrollY - containerRect.height - padding;
                
                // If viewport is too small, position at top with scrolling
                if (top < scrollY + padding) {
                    top = scrollY + padding;
                }
            }
        }

        // Add smooth transition
        this.container.style.transition = 'all 0.3s ease';
        this.container.style.left = `${left}px`;
        this.container.style.top = `${top}px`;

        // Add responsive positioning for mobile
        if (viewportWidth <= 480) {
            this.container.style.left = `${padding}px`;
            this.container.style.right = `${padding}px`;
            this.container.style.width = `calc(100% - ${padding * 2}px)`;
            this.container.style.bottom = `${padding}px`;
            this.container.style.top = 'auto';
        }
    }

    escapeText(text) {
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;')
            .replace(/\n/g, ' ')
            .trim();
    }

    // Add enable/disable methods
    enable() {
        this.enabled = true;
        this.init(); // Initialize event listeners only when enabled
    }

    disable() {
        this.enabled = false;
        this.hideContainer();
    }
}

// Auto-initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new WordDefinition();
});

// Alternative approach using IIFE (Immediately Invoked Function Expression)
(() => {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => new WordDefinition());
    } else {
        new WordDefinition();
    }
})();